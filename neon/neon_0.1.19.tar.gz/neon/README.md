neon README
================

The neon package serves as an R wrapper for the Smartabase API. At present, the package consists of two primary functions: `pull_smartabase()` for downloading Smartabase data into R and `push_smartabase()` for uploading data from R to Smartabase.

Installation
------------

To install neon - please contact your Smartabase Builder for instructions.

Getting started
---------------

`neon` provides some helper functions to setup various credentials. You can see a vignette for explaining those below.

``` r
vignette("getting-started", package = "neon")
```

Usage
-----

The two main functions of `neon` allow you to push and pull data from your Smartabase site via the Smartabase API. You can browse the vignettes below for in depth details on the workflow or for details each function.

``` r
browseVignettes("neon")
```

### pull\_smartabase()

The pull smartabase function allows you to pull data from Smartabase into R from a specific event form.

``` r
data <- pull_smartabase(
  url = "example.smartabase.com/neon",
  form = "Daily Wellness",
  username = "john.smith",
  password = "password123", 
  start_date = "01/01/2019",
  end_date = "01/02/2019"
)
```

### push\_smartabase()

The push smartabase function allows you to send data back to a Smartabase form.

``` r
push_smartabase(
  df = data,
  url = "example.smartabase.com/neon",
  form = "Daily Wellness",
  username = "john.smith",
  password = "password123"
)
```

Help
----

Contact either Zac Pross (<zac.pross@fusionsport.com>) or James Day (<james.day@fusionsport.com>) for questions about `neon`. Alternatively, contact your Smartabase Builder directly.
