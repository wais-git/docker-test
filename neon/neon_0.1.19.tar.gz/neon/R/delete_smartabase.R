#' delete_smartabase
#'
#' Deletes events using event ID
#'
#' This function accepts Smartabase event IDs and deletes any records
#' corresponding those event IDs
#' \code{vignette("deleting-data", package = "neon")}
#'
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param event_id numeric: event IDs of events to be deleted
#' @param cloud_mode boolean: if TRUE, no progress bar appears (i.e. for use
#' in non-local, cloud environments)
#'
#' @return Smartabase data
#'
#' @examples
#' \dontrun{
#' # Delete one record with event_id = 999 from example.smartabase.com/site:
#' delete_smartabase(
#'   url = "example.smartabase.com/site",
#'   username = "john.smith",
#'   password = "examplePassword",
#'   event_id = 999
#' )
#' }
#'
#' @export
delete_smartabase <- function(
  url = NULL,
  username = NULL,
  password = NULL,
  event_id,
  cloud_mode = FALSE
) {

  username <- .get_username(username)

  password <- .get_password(password)

  url <- stringr::str_replace(.get_url(url), "https://", "")

  if (password == "prompt") {
    password <- getPass::getPass(msg = paste("Smartabase password for", username, "at", url))
  }

  smartabase_url <- .create_url(url, "delete_event")
  body <- jsonlite::toJSON(list(
    eventId     = event_id
  ), auto_unbox = TRUE)

  if (!cloud_mode) {
    cat(paste("Deleting events... ", "\n\n"))

    post <- httr::POST(
      url = smartabase_url,
      httr::authenticate(username, password, type = "basic"),
      encode = "json",
      httr::content_type_json(),
      body = body,
      verbose = FALSE,
      httr::progress(type = "up")
    )

  } else {
    post <- httr::POST(
      url = smartabase_url,
      httr::authenticate(username, password, type = "basic"),
      encode = "json",
      httr::content_type_json(),
      body = body,
      verbose = FALSE
    )
  }

  if (httr::http_error(post)) {
    data <- NULL
    stop(paste(
      "Please check that your username, password and event IDs are correct"),
      call. = FALSE)
  }

  auth_status <- httr::http_status(post)[["category"]]

  auth_message <- httr::http_status(post)[["message"]]

  auth_message <- paste("Authentication", tolower(auth_message))

  if (auth_status == "Success") {
    # data_message <- paste0("Deletion successful")
    data_message <- httr::content(post, "text", encoding = "UTF-8")

    full_message <- paste0("\n", auth_message, "\n", data_message, "\n")

    message(full_message)
  }

  rm(password)
}
