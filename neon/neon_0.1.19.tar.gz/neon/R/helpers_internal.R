#' .log_errors
#'
#' Writes a log file detailing the rows where incorrect date or time formats
#' were detected
#'
#' @param df dataframe: dataframe for printing error rows to log file
#' @param row_indices vector: row indices where errors are found
#' @param msg string: error message from check function
#' @param var string: variable to log error for
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return Log file indicating which rows errors were found. To be fed into
#' check functions.
.log_errors <- function(df, row_indices, msg, var = NULL, cloud_mode) {

  if (length(row_indices) == 1) {
    error_rows <- paste0("Row ", row_indices, ". ")

  } else if (length(row_indices) <= 5) {
    error_rows <- paste0("Rows ", paste0(row_indices, collapse = ", "), ". ")

  } else {
    error_rows <- paste0("Multiple rows throwing errors")
  }

  if (is.null(var)) {
    error_elements <- data.frame(incorrect.elements = paste(row_indices))

    if (cloud_mode) {
      stop(
        Sys.time(), "\n",
        msg, "\n",
        paste(
          capture.output(
            print(error_elements, print.gap = 3, row.names = FALSE)
          ),
          collapse = "\n"),
        call. = FALSE
      )

    } else {
      utils::capture.output(paste("Error log:", Sys.time()),
                            paste0(msg),
                            cat("\n"),
                            print(error_elements, print.gap = 3, row.names = FALSE),
                            file = "log_file.txt")

      paste0(tolower(msg))
    }

  } else {
    error_rows_df <- data.frame(`row.number` = row_indices, row.names = NULL) %>%
      dplyr::mutate(var_name = df[row_indices, ] %>%
                      dplyr::rename_all(~ tolower(.)) %>%
                      dplyr::pull(tolower(var))) %>%
      dplyr::rename(!!dplyr::quo_name(var) := .data$var_name)

    if (cloud_mode) {
      stop(
        Sys.time(), "\n",
        error_rows, "\n",
        paste0("Please ensure that '", var, "'", msg), "\n",
        paste0(nrow(error_rows_df), " / ", nrow(df),
               " rows with errors in ", "'", var, "'", " variable"), "\n",
        paste(
          capture.output(
            print(error_rows_df, print.gap = 3, row.names = FALSE)
          ),
          collapse = "\n"
        ),
        call. = FALSE
      )

    } else {
      capture.output(paste("Error log:", Sys.time()),
                     paste0(error_rows),
                     paste0("Please ensure that '", var, "'", msg),
                     paste0(nrow(error_rows_df), " / ", nrow(df),
                            " rows with errors in ", "'", var, "'", " variable"),
                     cat("\n"),
                     print(error_rows_df, print.gap = 3, row.names = FALSE),
                     file = "log_file.txt")

      paste0(tolower(error_rows), "\nPlease ensure that '", var, "'", msg)
    }
  }
}


#' .check_date
#'
#' Returns error if start_date and/or end_date input/s in 'pull_smartabase()' or 'push_smartabase()' are
#' incorrect format
#'
#' This function takes in the start_date or end_date user input in
#' push_smartabase() and checks that it is 'dd/mm/yyyy'
#'
#' @param date string: start_date or end_date data to be checked
#' @param df dataframe: dataframe for printing error rows to log file
#' @param var string: start_date or end_date indicator
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return An error when the date input is not a string of the form
#' "dd/mm/yyyy"
.check_date <- function(date, df = NULL, var = NULL, cloud_mode) {

  if (any(nchar(date) != 10) | any(is.na(as.Date(date, "%d/%m/%Y")))) {
    row_indices <- which(nchar(date) != 10 | is.na(as.Date(date, "%d/%m/%Y")))

    msg <- paste(" values are of the form 'dd/mm/yyyy'")

    if (all(is.null(df), is.null(var))) {
      stop(paste0("please ensure that '", substitute(date), "'",
                  " (i.e. ", "'", date, "'", ")",
                  " is of the form dd/mm/yyyy"), call. = FALSE)

    } else {

      stop(.log_errors(df, row_indices, msg, var, cloud_mode),
           paste("\nSee log_file.txt in", getwd(), "for more details"),
           call. = FALSE)
    }
  }
}


#' .check_time
#'
#' Returns error if start_time and/or end_time input/s in push_smartabase()
#'  are incorrect format
#'
#' This function takes in the start_time or end_time user input in
#' push_smartabase() and checks that it is 'hh:mm AM/PM'.
#'
#' @param time string: parses start_time or end_time from push_smartabase()
#' @param df dataframe: for printing error rows to log file
#' @param var string: either start_date, end_date, start_time or end_time
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return an error when the time input is not a string of the form
#' 'hh:mm AM/PM'
.check_time <- function(time, df = NULL, var = NULL, cloud_mode) {

  check_colon <- !stringr::str_detect(time, ":")

  check_am <- stringr::str_detect(time, stringr::fixed("am", ignore_case = TRUE))

  check_pm <- stringr::str_detect(time, stringr::fixed("pm", ignore_case = TRUE))

  check_hour_max <- as.numeric(stringr::str_extract(time, ".*(?=:)")) > 12

  check_hour_min <- as.numeric(stringr::str_extract(time, ".*(?=:)")) < 0

  check_length <- nchar(time) < 7 | nchar(time) > 8

  if (any(check_colon)) {
    row_indices <- which(check_colon)

    msg <- paste0(" hours and minutes are seperated by a colon")

    if (all(is.null(df), is.null(var))) {
      stop(paste0("please ensure that '", substitute(time), "'",
                  " (i.e. ", "'", time, "'", ")",
                  " has the ", msg),
           call. = FALSE)

    } else {

      stop(.log_errors(df, row_indices, msg, var, cloud_mode), "\n",
           paste("See log_file.txt in", getwd(), "for more details"),
           call. = FALSE)
    }

  } else if (any(!(check_am | any(check_pm))) | any(check_length)) {
    row_indices <- which(!(check_am | check_pm) | check_length)

    msg <- paste(" is of the form 'h:mm AM' or 'h:mm PM'")

    if (all(is.null(df), is.null(var))) {
      stop(paste0("please ensure that '", substitute(time), "'",
                  " (i.e. ", "'", time, "'", ")",
                  msg),
           call. = FALSE)

    } else {

      stop(.log_errors(df, row_indices, msg, var, cloud_mode), "\n",
           paste("See log_file.txt in", getwd(), "for more details"),
           call. = FALSE)
    }

  } else if (any(check_hour_max) | any(check_hour_min)) {
    row_indices <- which(check_hour_max | check_hour_min)

    msg <- paste(" is in 12-hour format (hours must be >= 0 and <= 12)")

    if (all(is.null(df), is.null(var))) {
      stop(paste0("please ensure that '", substitute(time), "'",
                  " (i.e. ", "'", time, "'", ")",
                  msg),
           call. = FALSE)

    } else {

      stop(.log_errors(df, row_indices, msg, var, cloud_mode), "\n",
           paste("See log_file.txt in", getwd(), "for more details"),
           call. = FALSE)
    }
  }
}


#' .check_table_fields
#'
#' Returns error if table_fields input in push_smartabase() / .df_to_json()
#' do not exist as columns in the input dataframe.
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param table_fields vector: a vector of column names that are going into
#' be uploaded into a table
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return An error when the table_fields inputs do not exist as columns in the
#' input dataframe
.check_table_fields <- function(df, table_fields, cloud_mode) {

  if (!is.null(table_fields)) {
    if (!all(table_fields %in% names(df))) {
      row_indices <- table_fields[!table_fields %in% names(df)]

      msg <- paste("All elements of 'table_fields' must match column names of",
                   "the input dataframe")

      stop(.log_errors(df, row_indices, var = NULL, msg, cloud_mode), "\n",
           paste("See log_file.txt in", getwd(), "for more details"),
           call. = FALSE)
    }
  }
}


#' .rm_delim
#'
#' Removes underscore or period from string.
#'
#' @param input string
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return string with underscores and periods removed
.rm_delim <- function(input) {
  stringr::str_remove_all(input, "_|\\.")
}


#' .to_lower_and_check
#'
#' Renames start/end date/time inputs
#'
#' Uploading to Smartabase requires the variables start_date, end_date,
#' start_time and end_time to be attached to the input dataframe. This
#' function looks for existing columns with those names, ignoring case,
#' underscores and periods, and renames to be API friendly. Lives in
#' .insert_metadata().
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param input string: name of start_date or end_date column to be converted
#' to dmy format#'
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return df with target column renamed
.to_lower_and_check <- function(df, input, cloud_mode) {

  target <- which(.rm_delim(tolower(names(df))) %in% tolower(.rm_delim(input)))

  if (stringr::str_detect(tolower(input), "date")) {
    .check_date(df[[target]], df, input, cloud_mode)

  } else {
    .check_time(df[[target]], df, input, cloud_mode)
  }

  if (input == "date") {
    df %>% dplyr::rename("start_date" := target)

  } else {
    df %>% dplyr::rename(!!dplyr::quo_name(input) := target)
  }
}


#' .create_url
#'
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param end_point string: api endpoint e.g. 'eventsearch'
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return url string
.create_url <- function(url, end_point) {

  base <- paste0("https://", url, "/api/v1/")

  end_point <- switch(end_point,
                      pull_profile     = "profilesearch",
                      pull_event       = "eventsearch",
                      pull_filtered_event = "filteredeventsearch",
                      push_profile     = "profileimport",
                      push_event       = "eventsimport",
                      pull_group_names = "listgroups",
                      pull_user        = "usersearch",
                      pull_current     = "currentgroup",
                      pull_group       = "groupmembers",
                      synchronise      = "synchronise",
                      delete_event     = "deleteevent"
  )

  params <- "informat=json&format=json"

  smartabase_url <- paste0(base, end_point, "?", params)

  return(smartabase_url)
}


#' .date_convert
#'
#' Converts "yyyy-mm-dd" dates into "ddmmyyyy".
#'
#' This function converts 'yyyy-mm-dd' dates into 'ddmmyyyy'; if
#' 'delimiter = TRUE', "dd/mm/yyyy" is returned. This function is needed to set
#' the default value for the start_date argument within 'push_smartabase()'.
#'
#' @param date string: format 'yyyy-mm-dd'
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return A date string of format 'ddmmyyyy' or 'dd/mm/yyyy'
.date_convert <- function(date) {

  day <- stringr::str_sub(date, -2)

  month <- stringr::str_sub(date, -5, -4)

  year <- stringr::str_sub(date, 1, 4)

  date_output <- paste0(day, "/", month, "/", year)

  return(date_output)
}


#' .convert_to_dmy
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param input string: name of start_date or end_date column to be converted
#' to dmy format
#' @param current_date_format string: current format of date variable of
#' interest
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return dataframe with date variable converted to dmy format
#'
#' @importFrom lubridate dmy
#' @importFrom lubridate ymd
#' @importFrom lubridate ydm
#' @importFrom lubridate mdy
#' @importFrom lubridate myd
#' @importFrom lubridate dym

.convert_to_dmy <- function(df, input, current_date_format, cloud_mode) {

  target <- which(.rm_delim(tolower(names(df))) %in% tolower(.rm_delim(input)))

  initial_na_count <- sum(is.na(df[[target]]))
  initial_na_row   <- which(is.na(df[[target]]))
  error_rows_df    <- df %>%
    tibble::rownames_to_column() %>%
    dplyr::select(row.number = .data$rowname, !!input) %>%
    as.data.frame()

  date_formats <- c("ymd", "ydm", "mdy", "myd", "dym", "dmy")

  if (!current_date_format %in% date_formats) {
    stop("'current_date_format' must have one of the following formats: ",
         paste0(date_formats, collapse = ", "),
         call. = FALSE)

  } else {
    date_parser <- eval(parse(text = current_date_format))
  }

  df <- df %>%
    dplyr::mutate_at(target, ~ format(as.Date(suppressWarnings(date_parser(.))), "%d/%m/%Y"))

  final_na_count <- sum(is.na(df[[target]]))
  final_na_row   <- which(is.na(df[[target]]))


  if (final_na_count > initial_na_count) {
    main_body1 <-
      paste0("Converting '", input, "' to 'dmy' failed for ",
             final_na_count - initial_na_count, " / ", nrow(df),
             " rows")
    main_body2 <-
      paste0("This may be because 1) current_date_format = '",
             current_date_format,
             "' is incorrect or 2) the '",
             input,
             "' column contains multiple date formats")

    screen_msg <- paste0(tolower(stringr::word(main_body1, 1)), " ",
                         stringr::word(main_body1, 2, -1),
                         "\n",
                         main_body2,
                         "\n",
                         "See log_file.txt in ", getwd(),
                         " for more details")

    row_indices   <- final_na_row[!final_na_row %in% initial_na_row]
    error_rows_df <- error_rows_df %>% dplyr::filter(.data$row.number %in% row_indices)

    if (cloud_mode) {
      stop(Sys.time(), "\n",
           main_body1, "\n",
           main_body2, "\n",
           paste0("The following rows are not ", current_date_format, " format: "), "\n",
           paste(capture.output(print(error_rows_df, print.gap = 3, row.names = FALSE)), collapse = "\n"),
           call. = FALSE)

      screen_msg <- NULL

    } else {
      capture.output(paste("Error log:", Sys.time()),
                     main_body1,
                     main_body2,
                     paste0("The following rows are not ", current_date_format, " format: "),
                     cat("\n"),
                     print(error_rows_df, print.gap = 3, row.names = FALSE),
                     file = "log_file.txt")
    }

  } else {
    screen_msg <- NULL
  }

  return(list(df, screen_msg))
}


#' .insert_metadata
#'
#' Adds start/end date columns and start/end time columns to df or points to
#' existing columns.
#'
#' Uploading to Smartabase requires the variables start_date, end_date,
#' start_time and end_time to be attached to the input dataframe. By default,
#' this function looks for variable names that match any of those arguments,
#' and if they are not found will set start_date = current date,
#' end_date = current date, start_time = current time and end_time =
#' current_time + 1 hour. If there is a variable called "Date" or "date", it
#' will automatically be renamed to start_date. The arguments also take in the
#' names of existing variables that should be renamed e.g. start_date =
#' `Session Date`.
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param start_date string: name of start date column in dataframe. If NULL,
#' and 'Date' or 'start_date' are not already columns in the dataframe, creates
#' a new start_date column based on current date
#' @param end_date string: name of end date column in dataframe. If NULL, and
#' 'end_date' is not already a column in the dataframe, creates a new
#' 'end_date' column based on 'start_date'
#' @param start_time string: name of start time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'start_time' is not already a
#' column in the dataframe, creates a new 'start_time' column based on
#' Sys.time()
#' @param end_time string: name of end time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'end_time' is not already a
#' column in the dataframe, creates a new 'end_time' column with values +1 hour
#' after 'start_time'
#' @param current_date_format string: current format of date variable of
#' interest. Set this argument to convert 'start_date' or 'end_date' to
#' dd/mm/yyyy
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return df with metadata attached
.insert_metadata <- function(df, entered_by_user_id, start_date, end_date,
                             start_time, end_time, current_date_format = NULL,
                             cloud_mode) {

  if (is.null(start_date) & !is.null(end_date)) {
    stop("'start_date' must be supplied when 'end_date' is supplied",
         call. = FALSE)
  }

  if (is.null(start_time) & !is.null(end_time)) {
    stop("'start_time' must be supplied when 'end_time' is supplied)",
         call. = FALSE)
  }

  # Insert entered_by_user_id
  if (is.null(entered_by_user_id)) {
    if (!.rm_delim("entered_by_user_id") %in% .rm_delim(tolower(names(df)))) {
      df <- df %>%
        dplyr::mutate(entered_by_user_id = .get_entered_by_user_id(entered_by_user_id = entered_by_user_id))

    } else {
      entered_by_col <- which(.rm_delim(names(df)) %in% .rm_delim("entered_by_user_id"))

      if (any(is.na(df[[entered_by_col]]))) {
        warning("Existing entered_by_user_id column contains NA, replacing with value in saved_credentials()",
                call. = FALSE, immediate. = TRUE)

        df <- df %>%
          dplyr::mutate_at("entered_by_user_id", ~ case_when(
            is.na(.data$entered_by_user_id) ~ as.character(.get_entered_by_user_id(entered_by_user_id = NULL)),
            TRUE ~ .
          ))
      }
    }

  } else if (entered_by_user_id %in% names(df)) {
    df <- df %>% dplyr::mutate_("entered_by_user_id" = entered_by_user_id)

  } else {

    df <- df %>%
      dplyr::select(-dplyr::matches("entered_by_user_id")) %>%
      dplyr::mutate(entered_by_user_id = entered_by_user_id)

    # stop(paste0("entered_by_user_id` must reference a variable in the dataframe. ",
    #             "There is no variable called '", entered_by_user_id, "'."), call. = FALSE)
  }

  # Insert start_time
  if (is.null(start_time)) {
    if (.rm_delim("start_time") %in% .rm_delim(tolower(names(df)))) {
      df <- .to_lower_and_check(df, "start_time", cloud_mode)

    } else {

      current_time_raw <- lubridate::now()

      current_time_24 <- lubridate::hour(current_time_raw)

      current_time <- format(
        strptime(stringr::str_sub(current_time_raw, 12, 17),
                 format = "%H:%M"), "%I:%M %p")

      current_time_ampm <- stringr::str_extract(current_time, "AM|PM")

      df <- df %>%
        dplyr::mutate(start_time = current_time)
    }

  } else if (start_time %in% names(df)) {
    .check_time(df[[start_time]], df, paste0(start_time), cloud_mode)

    df <- df %>% dplyr::mutate_("start_time" = start_time)

  } else {

    stop(paste0("start_time` must reference a variable in the dataframe. ",
                "There is no variable called '", start_time, "'."), call. = FALSE)
  }

  .check_time(df$start_time, df, "start_time", cloud_mode)

  # Insert end_time
  if (is.null(end_time)) {
    if (.rm_delim("end_time") %in% .rm_delim(tolower(names(df)))) {
      df <- .to_lower_and_check(df, "end_time", cloud_mode)

    } else {

      current_end_time_raw <- current_time_raw + lubridate::hours(1)

      current_end_time_24 <- lubridate::hour(current_end_time_raw)

      current_end_time <- format(
        strptime(stringr::str_sub(current_end_time_raw, 12, 17),
                 format = "%H:%M"), "%I:%M %p")

      current_end_time_ampm <- stringr::str_extract(current_end_time, "AM|PM")

      df <- df %>%
        dplyr::mutate(end_time = current_end_time)
    }

  } else if (end_time %in% names(df)) {
    .check_time(df[[end_time]], df, paste0(end_time), cloud_mode)

    df <- df %>% dplyr::mutate_("end_time" = end_time)

  } else {

    stop(paste0("`end_time` must reference a variable in the dataframe. ",
                "There is no variable called '", end_time, "'."), call. = FALSE)
  }

  .check_time(df$end_time, df, "end_time", cloud_mode)

  # Insert start_date
  if (is.null(start_date)) {
    if (.rm_delim("start_date") %in% .rm_delim(tolower(names(df)))) {
      if (!is.null(current_date_format)) {
        data <- .convert_to_dmy(df, "start_date", current_date_format, cloud_mode)

        df <- data[[1]]

        if (!cloud_mode & !is.null(data[[2]])) {
          stop(data[[2]], call. = FALSE)
        }
      }

      df <- .to_lower_and_check(df, "start_date", cloud_mode)

    } else if (.rm_delim("date") %in% .rm_delim(tolower(names(df)))) {
      target <- names(df)[which(.rm_delim("date") %in% .rm_delim(tolower(names(df))))]

      if (!is.null(current_date_format)) {
        data <- .convert_to_dmy(df, target, current_date_format, cloud_mode)

        df <- data[[1]]

        if (!cloud_mode & !is.null(data[[2]])) {
          stop(paste(data[[2]]), call. = FALSE)
        }
      }

      df <- .to_lower_and_check(df, "date", cloud_mode)

    } else {

      df <- df %>%
        dplyr::mutate(start_date = .date_convert(Sys.Date()))
    }

  } else if (start_date %in% names(df)) {
    if (!is.null(current_date_format)) {
      data <- .convert_to_dmy(df, start_date, current_date_format, cloud_mode)

      df <- data[[1]]

      if (!cloud_mode & !is.null(data[[2]])) {
        stop(paste(data[[2]]), call. = FALSE)
      }
    }

    .check_date(df[[start_date]], df, paste0(start_date), cloud_mode)

    df <- df %>%
      dplyr::mutate_("start_date" = start_date)

  } else {

    stop(paste0("`start_date` must reference a variable in the dataframe. ",
                "There is no variable called '", start_date, "'."), call. = FALSE)
  }

  .check_date(df$start_date, df, "start_date", cloud_mode)

  # Insert end_date
  if (is.null(end_date)) {
    if ("end_date" %in% tolower(names(df))) {
      if (!is.null(current_date_format)) {
        data <- .convert_to_dmy(df, "end_date", current_date_format, cloud_mode)

        df <- data[[1]]

        if (!cloud_mode & !is.null(data[[2]])) {
          stop(paste(data[[2]]), call. = FALSE)
        }
      }

      df <- .to_lower_and_check(df, "end_date", cloud_mode)

    } else {

      df <- df %>%
        dplyr::mutate(end_date = dplyr::case_when(
          current_time_ampm == "PM" & current_end_time_ampm == "AM" ~ .date_convert(lubridate::dmy(start_date) + lubridate::days(1)),
          TRUE ~ start_date
        ))
    }

  } else if (end_date %in% names(df)) {
    if (!is.null(current_date_format)) {
      data <- .convert_to_dmy(df, end_date, current_date_format, cloud_mode)

      df <- data[[1]]

      if (!cloud_mode & !is.null(data[[2]])) {
        stop(paste(data[[2]]), call. = FALSE)
      }
    }

    df <- df %>% dplyr::mutate_("end_date" = end_date)

  } else {

    stop(paste0("`end_date` must reference a variable in the dataframe. ",
                "There is no variable called '", end_date, "'."), call. = FALSE)
  }

  df <- df[!names(df) %in% c("end_hours", "end_mins", "end_ampm", "start_ampm")]

  .check_date(df$end_date, df, "end_date", cloud_mode)

  return(df)
}

#' .prepare_data
#'
#' Convert dataframe to required JSON structure for Smartabase API upload
#'
#' This function takes in a dataframe and converts into a specific list
#' structure, and then JSON, which is required by the Smartabase API.
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param form string: Name of Smartabase form
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param entered_by_user_id string: user ID of user uploading the data -- can
#' leave blank if setup with save_credentials()
#' @param type string: either 'event', 'profile' or 'synchronise'
#' @param get_id boolean: if TRUE, searches for user IDs of athletes listed
#' in dataframe (requires a value supplied to 'match_id_to_column')
#' @param match_id_to_column string: names of columns in dataframe that match
#' either 'about', 'username' or 'email'. User IDs will be returned that match
#' dataframe values. Requires 'get_id' = TRUE
#' @param table_fields vector: supply a vector of column names that are going
#' into be uploaded into a table. In Smartabase, this is equivalent to ticking
#' 'Treat all records for the same user, on the same day as a single record?'
#' @param start_date string: name of start date column in dataframe. If NULL,
#' and 'Date' or 'start_date' are not already columns in the dataframe, creates
#' a new start_date column based on current date
#' @param end_date string: name of end date column in dataframe. If NULL, and
#' 'end_date' is not already a column in the dataframe, creates a new
#' 'end_date' column based on 'start_date'
#' @param start_time string: name of start time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'start_time' is not already a
#' column in the dataframe, creates a new 'start_time' column based on
#' Sys.time()
#' @param end_time string: name of end time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'end_time' is not already a
#' column in the dataframe, creates a new 'end_time' column with values +1 hour
#' after 'start_time'
#' @param current_date_format string: current format of date variable of
#' interest. Set this argument to convert 'start_date' or 'end_date' to
#' dd/mm/yyyy
#' @param edit_event boolean: if TRUE, will look for 'event_id' in dataframe.
#' Records with matching event_id on Smartabase will be overwritten with the
#' new data
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#' @param ... Additional arguments to jsonlite::toJSON
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return Data to be uploaded to Smartabase - 'JSON'
#'
#' @examples
#' \dontrun{
#' example_df <- dplyr::tibble(
#'   user_id = c(31813, 31819),
#'   `Body Weight pre training` = round(runif(2, 82, 92), 0),
#'   `Body Weight post training` = round(runif(2, 82, 92), 0),
#'   `Urine Colour` = round(runif(2, 1, 8), 0)
#' )
#' .prepare_data(
#'   df = example_df,
#'   url = "demo.smartabase.com/apidev",
#'   form = "Hydration (SS)"
#' )
#' }
.prepare_data <- function(df,
                          form,
                          url = NULL,
                          type = "event",
                          username = NULL,
                          password = NULL,
                          entered_by_user_id = NULL,
                          match_id_to_column = NULL,
                          id_message = FALSE,
                          get_id = FALSE,
                          table_fields = NULL,
                          start_date = NULL,
                          end_date   = NULL,
                          current_date_format = NULL,
                          start_time = NULL,
                          end_time   = NULL,
                          edit_event = FALSE,
                          cloud_mode = FALSE,
                          ...) {

  if (!any(class(df) == "data.frame")) {
    stop("please supply a data.frame via the 'df' argument",
         call. = FALSE)
  }

  df <- .insert_metadata(df, entered_by_user_id = entered_by_user_id,
                         start_date = start_date, end_date = end_date,
                         current_date_format = current_date_format,
                         start_time = start_time, end_time = end_time,
                         cloud_mode = cloud_mode)

  rm_cols <- which(
    tolower(.rm_delim(names(df))) %in%
      c(tolower(.rm_delim("First Name")), tolower(.rm_delim("Last Name")))
  )

  if (length(rm_cols) > 0) {
    df <- df[-rm_cols]
  }


  if ("event_id" %in% names(df)) {
    df <- df %>% dplyr::mutate_at(dplyr::vars(-.data$event_id), ~ ifelse(is.na(.), paste(""), .))
  } else {
    df <- df %>% dplyr::mutate_all(~ ifelse(is.na(.), paste(""), .))
  }

  # Make id matching columns (and already existing user_id column) lowercase
  id_columns <- c("about", "user_id", "username", "email", "event_id")

  if (any(.rm_delim(id_columns) %in% .rm_delim(tolower(names(df))))) {
    df_names <- .rm_delim(names(df))

    df_lower_names <- tolower(df_names)

    names_ignore <- df_names[!df_names %in% df_lower_names & !tolower(df_names) %in% .rm_delim(id_columns)]

    names_to_rename <- names(df)[!names(df) %in% names_ignore & tolower(names(df)) %in% .rm_delim(id_columns)] %>% sort()

    id_columns <- id_columns[.rm_delim(id_columns) %in% tolower(names_to_rename)] %>% sort()

    df <- df %>% dplyr::rename_at(dplyr::vars(names_to_rename), ~ id_columns)
  }

  if (get_id) {
    username <- .get_username(username)

    password <- .get_password(password)

    url <- .get_url(url)

    url <- stringr::str_replace(url, "https://", "")

    lower_match_id <- tolower(.rm_delim(match_id_to_column))

    if (!any(tolower(.rm_delim(names(df))) == lower_match_id)) {
      stop(paste0("'", match_id_to_column,
                  "' must exist as a column in the dataframe when match_id_to_column = ",
                  match_id_to_column ," and get_id = TRUE."), call. = FALSE)
    }

    if (password == "prompt") {
      password <- getPass::getPass(msg = paste("Smartabase password for", username, "at", url))
    }

    if ("user_id" %in% names(df) | "userid" %in% names(df)) {
      df <- df[!names(df) %in% c("user_id", "userid")]
    }

    if (is.null(match_id_to_column)) {
      stop("'match_id_to_column' must be supplied when get_id = TRUE",
           call. = FALSE)

    } else if (lower_match_id == "about") {
      filter_user_value <- unique(df$about)

    } else if (lower_match_id == "username") {
      filter_user_value <- unique(df$username)

    } else if (lower_match_id == "email") {
      filter_user_value <- unique(df$email)
    }

    id_data <- get_id(url = url,
                      filter_user_key = lower_match_id,
                      filter_user_value = filter_user_value,
                      start_date = "01/01/1970",
                      end_date = .date_convert(lubridate::today()),
                      username = username,
                      password = password) %>%
      dplyr::select(.data$user_id, !!lower_match_id) %>%
      dplyr::distinct(.data$user_id, !!dplyr::sym(lower_match_id), .keep_all = TRUE)

    if (any(duplicated(id_data$about))) {
      dup_names <- id_data %>%
        dplyr::count(.data$about) %>%
        dplyr::filter(.data$n > 1) %>%
        dplyr::pull(.data$about)

      dup_names <- sub(",([^,]*)$", " and\\1", paste(dup_names, collapse = ", "))

      stop(paste0("there are multiple Smartabase accounts with the following first and last names: ",
                  paste(dup_names, collapse = ", "),
                  ".\nPlease either",
                  "\n  1. run the get_id() function, manually join the user IDs to the dataframe ",
                  "and set get_id = FALSE in push_smartabase().",
                  "\n  2. set match_id_to_column to 'email' or 'username' and ",
                  "provide an email or username column in the dataframe.",
                  "\n  3. remove the athletes with multiple accounts from the dataframe."),
           call. = FALSE)
    }

    df <- dplyr::left_join(df, id_data, by = lower_match_id)
  }

  if (!"user_id" %in% names(df)) {
    stop(paste0("'user_id' must exist as a column in the dataframe when get_id = FALSE"),
         call. = FALSE)
  }

  return(df)
}


#' .df_to_json
#'
#' Convert dataframe to required JSON structure for Smartabase API upload
#'
#' This function takes in a dataframe and converts into a specific list
#' structure, and then JSON, which is required by the Smartabase API.
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param form string: Name of Smartabase form
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param entered_by_user_id string: user ID of user uploading the data -- can
#' leave blank if setup with save_credentials()
#' @param type string: either 'event', 'profile' or 'synchronise'
#' @param get_id boolean: if TRUE, searches for user IDs of athletes listed
#' in dataframe (requires a value supplied to 'match_id_to_column')
#' @param match_id_to_column string: names of columns in dataframe that match
#' either 'about', 'username' or 'email'. User IDs will be returned that match
#' dataframe values. Requires 'get_id' = TRUE
#' @param table_fields vector: supply a vector of column names that are going
#' into be uploaded into a table. In Smartabase, this is equivalent to ticking
#' 'Treat all records for the same user, on the same day as a single record?'
#' @param start_date string: name of start date column in dataframe. If NULL,
#' and 'Date' or 'start_date' are not already columns in the dataframe, creates
#' a new start_date column based on current date
#' @param end_date string: name of end date column in dataframe. If NULL, and
#' 'end_date' is not already a column in the dataframe, creates a new
#' 'end_date' column based on 'start_date'
#' @param start_time string: name of start time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'start_time' is not already a
#' column in the dataframe, creates a new 'start_time' column based on
#' Sys.time()
#' @param end_time string: name of end time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'end_time' is not already a
#' column in the dataframe, creates a new 'end_time' column with values +1 hour
#' after 'start_time'
#' @param current_date_format string: current format of date variable of
#' interest. Set this argument to convert 'start_date' or 'end_date' to
#' dd/mm/yyyy
#' @param edit_event boolean: if TRUE, will look for 'event_id' in dataframe.
#' Records with matching event_id on Smartabase will be overwritten with the
#' new data
#' @param cloud_mode boolean: if TRUE, logs will be printed to screen instead
#' of saved to a text file (i.e. for use in non-local, cloud environments)
#' @param ... Additional arguments to jsonlite::toJSON
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return Data to be uploaded to Smartabase - 'JSON'
#'
#' @examples
#' \dontrun{
#' example_df <- dplyr::tibble(
#'   user_id = c(31813, 31819),
#'   `Body Weight pre training` = round(runif(2, 82, 92), 0),
#'   `Body Weight post training` = round(runif(2, 82, 92), 0),
#'   `Urine Colour` = round(runif(2, 1, 8), 0)
#' )
#' .df_to_json(
#'   df = example_df,
#'   url = "demo.smartabase.com/apidev",
#'   form = "Hydration (SS)"
#' )
#' }
.df_to_json <- function(df,
                        form,
                        url = NULL,
                        type = "event",
                        username = NULL,
                        password = NULL,
                        entered_by_user_id = NULL,
                        match_id_to_column = NULL,
                        id_message = FALSE,
                        get_id = FALSE,
                        table_fields = NULL,
                        start_date = NULL,
                        end_date   = NULL,
                        current_date_format = NULL,
                        start_time = NULL,
                        end_time   = NULL,
                        edit_event = FALSE,
                        cloud_mode = FALSE,
                        ...) {

  df <- .prepare_data(
    df = df,
    url = url,
    form = form,
    username = username,
    password = password,
    entered_by_user_id = entered_by_user_id,
    match_id_to_column = match_id_to_column,
    get_id = get_id,
    table_fields = table_fields,
    start_date = start_date,
    end_date   = end_date,
    current_date_format = current_date_format,
    start_time = start_time,
    end_time   = end_time,
    edit_event = edit_event,
    cloud_mode = cloud_mode
  )

  df_to_list <- function(df, n_row) {

    if (type == "profile") {

      metadata <- dplyr::tibble(
        formName = form,
        enteredByUserId = df[["entered_by_user_id"]][[n_row]]
      ) %>%
        as.list()

    } else {

      if (edit_event) {
        if (!tolower(.rm_delim("event_id")) %in% tolower(.rm_delim(names(df)))) {
          stop("'event_id' must exist as a column in the dataframe when edit_event = TRUE")
        }

        metadata <- dplyr::tibble(
          formName = form,
          startDate = df[["start_date"]][[n_row]],
          finishDate = df[["end_date"]][[n_row]],
          startTime = df[["start_time"]][[n_row]],
          finishTime = df[["end_time"]][[n_row]],
          enteredByUserId = df[["entered_by_user_id"]][[n_row]],
          existingEventId = as.numeric(df[["event_id"]][[n_row]])
        ) %>%
          as.list()

      } else {

        metadata <- dplyr::tibble(
          formName = form,
          startDate = df[["start_date"]][[n_row]],
          finishDate = df[["end_date"]][[n_row]],
          startTime = df[["start_time"]][[n_row]],
          finishTime = df[["end_time"]][[n_row]],
          enteredByUserId = df[["entered_by_user_id"]][[n_row]]
        ) %>%
          as.list()
      }
    }

    userId <- list(userId = list(
      userId = df[n_row, ] %>%
        dplyr::pull(.data$user_id)
    ))

    remove_vars <- c("user_id", "about", "form", "username", "email",
                     "start_date", "end_date", "start_time", "end_time",
                     "entered_by_user_id", "event_id")

    df <- df[!names(df) %in% remove_vars]

    n_col <- ncol(df)

    create_table_data <- function(n_row) {

      if (!is.null(table_fields)) {
        .check_table_fields(df, table_fields, cloud_mode)

        num_row <- n_row

      } else {

        num_row <- 1
      }

      if (num_row == 1) {
        list(
          row = 0,
          pairs = 1:n_col %>%
            purrr::map(~ list(key = names(df[.x]), value = paste(df[.x][[1]][[n_row]])))
        )

      } else {

        n_col <- ncol(df[names(df) %in% table_fields])

        list(
          row = (num_row - 1),
          pairs = 1:n_col %>%
            purrr::map(~ list(key = names(df[names(df) %in% table_fields][.x]),
                              value = paste(df[names(df) %in% table_fields][.x][[1]][[n_row]])))
        )
      }
    }

    data <- list(
      rows = 1:n_row %>% purrr::map(~ create_table_data(.x)))

    body <- append(metadata, userId) %>% append(., data)
    return(body)
  }

  extract_per_userid <- function(df) {
    df <- df %>%
      split(.$user_id) %>%
      purrr::map(~ .x %>%
                   split(.$start_date) %>%
                   purrr::map(~ .x))

    names(df) <- NULL
    df <- purrr::flatten(df)
    names(df) <- NULL
    df %>% purrr::map(~ df_to_list(.x, n_row = nrow(.x)))
  }

  if (type == "profile") {

    make_json <- function(df) {
      jsonlite::toJSON(
        extract_per_userid(df) %>% purrr::flatten(),
        auto_unbox = TRUE, pretty = TRUE)
    }

    json <- df %>%
      dplyr::mutate(row_num = dplyr::row_number()) %>%
      split(.$row_num) %>%
      purrr::map(~ make_json(.x %>% dplyr::select(-row_num)))

  } else {

    make_json <- function(df) {
      jsonlite::toJSON(
        purrr::map(1, ~  list(events = extract_per_userid(df))) %>% purrr::reduce(., append),
        auto_unbox = TRUE, pretty = TRUE)
    }

    json <- unique(df$entered_by_user_id) %>%
      purrr::map(~ make_json(df %>% dplyr::filter(entered_by_user_id == .x)))
  }
  json
}


#' .post_message
#'
#' Accepts POST response object and produces success/failure status message
#'
#' @param post reponse: httr reponse object
#' @param type string: either 'event', 'profile' or 'synchronise'
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return POST status message
.post_message <- function(post, type, entered_by_user_id) {

  auth_status <- httr::http_status(post)[["category"]]

  auth_message <- httr::http_status(post)[["message"]]

  full_message <- paste0("Authentication ", tolower(auth_message))

  if (auth_status == "Success") {

    post_content <- httr::content(post, "text", encoding = "UTF-8")

    upload_json <- jsonlite::fromJSON(post_content)

    if (type == "profile") {
      upload_status <- upload_json[["state"]]
      upload_message <- upload_json[["message"]]

    } else {
      upload_status <- upload_json[["eventImportResultForForm"]][["eventImportResults"]][["state"]]
      upload_message <- upload_json[["eventImportResultForForm"]][["eventImportResults"]][["message"]]
    }

    if (is.null(upload_status)) {
      upload_status <- upload_json[["result"]][["state"]]
      upload_message <- upload_json[["result"]][["message"]]
    }

    paste0(
      "\nAuthentication ", tolower(auth_message),
      "\n",
      paste0(upload_status, ": ", stringr::str_replace(upload_message, "\\..*", ""), " by user ", entered_by_user_id)
    )

  } else {
    paste0(
      "\n", full_message
    )
  }
}


#' .post_with_status
#'
#' Call httr::POST with body and cat_message as input
#'
#' @param url string: full Smartabase url with endpoint attached
#' @param username string: Smartabase username
#' @param password string: Smartabase password
#' @param type string: either 'event', 'profile' or 'synchronise'
#' @param body json: JSON body produced by .df_to_json
#' @param cat_message string: uploading message
#' @param cloud_mode boolean: if TRUE, no progress bar appears (i.e. for use
#' in non-local, cloud environments)
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return httr reponse object and uploading message
.post_with_status <- function(username,
                              push_password,
                              smartabase_url,
                              entered_by_user_id,
                              type,
                              body,
                              cat_message,
                              cloud_mode,
                              shiny_progress_code) {
  if (!cloud_mode) {
    cat(cat_message)

    if (is.null(shiny_progress_code)) {
      post <- body %>%
        purrr::map(~ httr::POST(
          url = smartabase_url,
          httr::authenticate(username, push_password, type = "basic"),
          encode = "json",
          httr::content_type_json(),
          body = .x,
          verbose = FALSE,
          httr::progress(type = "up")
        ))

    } else {
      post <- body %>%
        purrr::map(~ httr::POST(
          url = smartabase_url,
          httr::authenticate(username, push_password, type = "basic"),
          encode = "json",
          httr::content_type_json(),
          body = .x,
          verbose = FALSE,
          eval(shiny_progress_code)
        ))
    }

  } else {

    if (is.null(shiny_progress_code)) {
      post <- body %>%
        purrr::map(~ httr::POST(
          url = smartabase_url,
          httr::authenticate(username, push_password, type = "basic"),
          encode = "json",
          httr::content_type_json(),
          body = .x,
          verbose = FALSE
        ))

    } else {
      post <- body %>%
        purrr::map(~ httr::POST(
          url = smartabase_url,
          httr::authenticate(username, push_password, type = "basic"),
          encode = "json",
          httr::content_type_json(),
          body = .x,
          verbose = FALSE,
          eval(shiny_progress_code)
        ))
    }
  }
  message(post %>% purrr::map(~ .post_message(.x, type, entered_by_user_id)))
}

#' .create_confirm_txt
#'
#' Create the text that will appear in the confirmation message when
#' edit_event = TRUE
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return text to appear in confirm message
.create_confirm_text <- function(
  nrow_existing,
  nrow_new = NULL,
  new_record = FALSE,
  duplicate = FALSE,
  multiple_id = FALSE
) {
  msg <- paste("Are you sure you want edit", nrow_existing,
               "existing records? The new data will overwrite the old data.")
  if (new_record) {
    new_record <- paste("You will also add", nrow_new, "new records.")
    msg <- paste(msg, new_record, sep = "\n\n")
  }

  if (multiple_id) {
    multiple_id <- paste(
      "Note: multiple entered_by_user_id values were detected.",
      "The API will be invoked separately for each entered_by_user_id."
    )
    msg <- paste(msg, multiple_id, sep = "\n\n")
  }

  if (duplicate) {
    duplicate <- paste(
      "Note: multiple records with the same user_id/start_date were detected.",
      "Given that table_fields = NULL, the API will be invoked multiple times."
    )
    msg <- paste(msg, duplicate, sep = "\n\n")
  }
  return(msg)
}


#' .push_confirmation_message
#'
#' Call httr::POST with body and cat_message as input
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param duplicate_test numeric: max number of user_id/start_date duplicate
#' pairings when table_fields = NULL
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param form string: Name of Smartabase form
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param entered_by_user_id string: user ID of user uploading the data --
#' ignore if setup with save_credentials()
#' @param type string: either 'event' or 'profile'
#' @param get_id boolean: if TRUE, searches for user IDs of athletes listed
#' in dataframe (requires a value supplied to 'match_id_to_column')
#' @param match_id_to_column string: names of columns in dataframe that match
#' either 'about', 'username' or 'email'. User IDs will be returned that match
#' dataframe values. Requires 'get_id' = TRUE
#' @param table_fields vector: supply a vector of column names that are going
#' to be uploaded into a table. In Smartabase, this is equivalent to ticking
#' 'Treat all records for the same user, on the same day as a single record?'
#' @param start_date string: name of start date column in dataframe. If NULL,
#' and 'Date' or 'start_date' are not already columns in the dataframe, creates
#' a new start_date column based on current date
#' @param end_date string: name of end date column in dataframe. If NULL, and
#' 'end_date' is not already a column in the dataframe, creates a new
#' 'end_date' column based on 'start_date'
#' @param start_time string: name of start time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'start_time' is not already a
#' column in the dataframe, creates a new 'start_time' column based on
#' Sys.time()
#' @param end_time string: name of end time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'end_time' is not already a
#' column in the dataframe, creates a new 'end_time' column with values +1 hour
#' after 'start_time'
#' @param current_date_format string: current format of date variable of
#' interest. Set this argument to convert 'start_date' or 'end_date' to
#' dd/mm/yyyy
#' @param edit_event boolean: if TRUE, will look for 'event_id' in dataframe.
#' Records with matching event_id on Smartabase will be overwritten with the
#' new data
#' @param cloud_mode boolean: if TRUE, confirmation pop-up will not appear when
#' editing events (i.e. for use in non-local, cloud environments)
#' @param shiny_progress_code string: shinyhttr code to pass progress bar to
#' a shiny app
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return httr reponse object and uploading message
.push_confirmation_message <- function(
  df,
  duplicate_test,
  form,
  url = NULL,
  username = NULL,
  password = NULL,
  entered_by_user_id = NULL,
  type = "event",
  get_id = FALSE,
  match_id_to_column = NULL,
  table_fields = NULL,
  start_date = NULL,
  end_date   = NULL,
  current_date_format = NULL,
  start_time = NULL,
  end_time   = NULL,
  edit_event = FALSE,
  cloud_mode = FALSE,
  shiny_progress_code = NULL
) {
  if (type != "profile" & edit_event) {

    if (is.null(entered_by_user_id)) {
      if (.rm_delim("entered_by_user_id") %in% .rm_delim(tolower(names(df)))) {
        unique_entered_by_user_id <- unique(df$entered_by_user_id)

        if (length(unique_entered_by_user_id) > 1) {
          multiple_id <- TRUE
        } else {
          multiple_id <- FALSE
        }
      }
    } else {
      multiple_id <- FALSE
    }

    if (any(is.na(df$event_id))) {
      df_edit <- df %>% dplyr::filter(!is.na(.data$event_id))

      df_no_edit <- df %>%
        dplyr::filter(is.na(.data$event_id)) %>%
        dplyr::mutate_all(~ ifelse(is.na(.), paste(""), .))

      n_row <- list(df_edit, df_no_edit) %>%
        purrr::map(
          ~ .x %>%
            {if (is.null(entered_by_user_id)) {
              dplyr::group_by(., .data$entered_by_user_id)
            } else .} %>%
            {if (!is.null(table_fields)) {
              dplyr::distinct(., .data$start_date, .data$user_id)
            } else .} %>%
            dplyr::summarise(n_row = dplyr::n()) %>%
            dplyr::arrange(desc(n_row)) %>%
            dplyr::pull(n_row) %>%
            purrr::map(~.x)
        )

      if (is.null(table_fields)) {
        if (duplicate_test > 1) {
          confirm_message <- .create_confirm_text(
            nrow_existing = purrr::reduce(n_row[[1]], sum),
            nrow_new = purrr::reduce(n_row[[2]], sum),
            new_record = TRUE,
            duplicate = TRUE,
            multiple_id = multiple_id
          )

        } else {
          confirm_message <- .create_confirm_text(
            nrow_existing = purrr::reduce(n_row[[1]], sum),
            nrow_new = purrr::reduce(n_row[[2]], sum),
            new_record = TRUE,
            multiple_id = multiple_id
          )
        }
      }

    } else {
      n_row <- df %>%
        {if (!is.null(table_fields)) {
          dplyr::distinct(., .data$start_date, .data$user_id)
        } else .} %>%
        nrow()


      if (duplicate_test > 1 & is.null(table_fields)) {
        confirm_message <- .create_confirm_text(
          nrow_existing = n_row,
          duplicate = TRUE,
          multiple_id = multiple_id
        )

      } else {
        confirm_message <- .create_confirm_text(
          nrow_existing = n_row,
          multiple_id = multiple_id
        )
      }
    }

    if (!cloud_mode) {
      message("Please respond to pop-up prompt")

      confirm_edit <- utils::askYesNo(
        msg = confirm_message
      )

      if (!confirm_edit | is.na(confirm_edit)) {
        stop(paste("data upload was aborted"), call. = FALSE)
      }
    }
  }
}


#' .prepare_data_and_push
#'
#' Call httr::POST with body and cat_message as input
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param form string: Name of Smartabase form
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param entered_by_user_id string: user ID of user uploading the data --
#' ignore if setup with save_credentials()
#' @param type string: either 'event' or 'profile'
#' @param get_id boolean: if TRUE, searches for user IDs of athletes listed
#' in dataframe (requires a value supplied to 'match_id_to_column')
#' @param match_id_to_column string: names of columns in dataframe that match
#' either 'about', 'username' or 'email'. User IDs will be returned that match
#' dataframe values. Requires 'get_id' = TRUE
#' @param table_fields vector: supply a vector of column names that are going
#' to be uploaded into a table. In Smartabase, this is equivalent to ticking
#' 'Treat all records for the same user, on the same day as a single record?'
#' @param start_date string: name of start date column in dataframe. If NULL,
#' and 'Date' or 'start_date' are not already columns in the dataframe, creates
#' a new start_date column based on current date
#' @param end_date string: name of end date column in dataframe. If NULL, and
#' 'end_date' is not already a column in the dataframe, creates a new
#' 'end_date' column based on 'start_date'
#' @param start_time string: name of start time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'start_time' is not already a
#' column in the dataframe, creates a new 'start_time' column based on
#' Sys.time()
#' @param end_time string: name of end time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'end_time' is not already a
#' column in the dataframe, creates a new 'end_time' column with values +1 hour
#' after 'start_time'
#' @param current_date_format string: current format of date variable of
#' interest. Set this argument to convert 'start_date' or 'end_date' to
#' dd/mm/yyyy
#' @param edit_event boolean: if TRUE, will look for 'event_id' in dataframe.
#' Records with matching event_id on Smartabase will be overwritten with the
#' new data
#' @param cloud_mode boolean: if TRUE, confirmation pop-up will not appear when
#' editing events (i.e. for use in non-local, cloud environments)
#' @param shiny_progress_code string: shinyhttr code to pass progress bar to
#' a shiny app
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return httr reponse object and uploading message
.prepare_data_and_push <- function(
  df,
  form,
  url = NULL,
  username = NULL,
  password = NULL,
  entered_by_user_id = NULL,
  type = "event",
  get_id = FALSE,
  match_id_to_column = NULL,
  table_fields = NULL,
  start_date = NULL,
  end_date   = NULL,
  current_date_format = NULL,
  start_time = NULL,
  end_time   = NULL,
  edit_event = FALSE,
  cloud_mode = FALSE,
  shiny_progress_code = NULL
) {
  create_message <- function(data, msg) {
    paste0("\nUploading ", data, msg, form, "... \n\n")
  }

  if (type == "profile") {
    smartabase_url <- .create_url(url, "push_profile")

    df <- df %>%
      dplyr::mutate(row_num = 1:nrow(.))

    n_row <- 1

  } else {
    smartabase_url <- .create_url(url, "push_event")

    n_row <- df %>%
      split(.$entered_by_user_id) %>%
      purrr::map(~ .x %>%
                   {if (!is.null(table_fields)) {
                     dplyr::distinct(., .data$start_date, .data$user_id)
                   } else . } %>%
                   nrow()
      )
  }

  cat_message <- n_row %>% purrr::map(~ create_message(.x, " records to "))

  entered_by_values <- df %>%
    dplyr::distinct(.data$entered_by_user_id) %>%
    dplyr::pull()

  body <- .df_to_json(
    df = df,
    url = url,
    form = form,
    type = type,
    username = username,
    password = password,
    entered_by_user_id = entered_by_user_id,
    match_id_to_column = match_id_to_column,
    get_id = get_id,
    table_fields = table_fields,
    start_date = start_date,
    end_date   = end_date,
    current_date_format = current_date_format,
    start_time = start_time,
    end_time   = end_time,
    edit_event = edit_event,
    cloud_mode = cloud_mode
  )

  if (type != "profile" & edit_event) {
    if (any(is.na(df$event_id))) {
      df_edit <- df %>% dplyr::filter(!is.na(.data$event_id))

      df_no_edit <- df %>%
        dplyr::filter(is.na(.data$event_id)) %>%
        dplyr::mutate_all(~ ifelse(is.na(.), paste(""), .))

      body <- purrr::map2(
        list(df_edit, df_no_edit), list(TRUE, FALSE),
        ~ .df_to_json(
          df = .x,
          url = url,
          form = form,
          username = username,
          password = password,
          entered_by_user_id = entered_by_user_id,
          match_id_to_column = match_id_to_column,
          get_id = get_id,
          table_fields = table_fields,
          start_date = start_date,
          end_date   = end_date,
          current_date_format = current_date_format,
          start_time = start_time,
          end_time   = end_time,
          edit_event = .y,
          cloud_mode = cloud_mode
        )
      )

      if (is.null(entered_by_user_id)) {
        if (.rm_delim("entered_by_user_id") %in% .rm_delim(tolower(names(df)))) {

          n_row <- list(df_edit, df_no_edit) %>%
            purrr::map(~ .x %>%
                         dplyr::group_by(entered_by_user_id) %>%
                         dplyr::distinct(.data$start_date, .data$user_id) %>%
                         dplyr::summarise(n_row = dplyr::n()) %>%
                         dplyr::arrange(desc(n_row)) %>%
                         dplyr::pull(n_row) %>%
                         purrr::map(~.x)
            )

          entered_by_values <- list(df_edit, df_no_edit) %>%
            purrr::map(~ .x %>%
                         dplyr::distinct(.data$entered_by_user_id) %>%
                         {if (nrow(.) > 1) {
                           dplyr::mutate(., row_num = 1:dplyr::n()) %>%
                             split(.$row_num) %>%
                             purrr::map(~ dplyr::pull(.x['entered_by_user_id']))
                         } else dplyr::pull(., entered_by_user_id)}
            ) %>%
            purrr::flatten()
        }
      } else {
        n_row <- list(df_edit, df_no_edit) %>%
          purrr::map(~ .x %>%
                       dplyr::distinct(.data$start_date, .data$user_id) %>%
                       dplyr::summarise(n_row = dplyr::n()) %>%
                       dplyr::arrange(desc(n_row)) %>%
                       dplyr::pull(n_row) %>%
                       purrr::map(~.x)
          )
      }

      new_cat_message <- n_row[[2]] %>% purrr::map(~ create_message(.x, " new records to "))

      edit_cat_message <- n_row[[1]] %>% purrr::map(~ create_message(.x, " existing records in "))

      cat_message <- append(edit_cat_message, new_cat_message)

    } else {
      cat_message <- n_row %>% purrr::map(~ create_message(.x, " existing records in "))
    }
  }

  invisible(purrr::pmap(
    list(x = purrr::flatten(body), y = cat_message, z = entered_by_values),
    function(x, y, z) {
      .post_with_status(username = username,
                        push_password = password,
                        smartabase_url = smartabase_url,
                        entered_by_user_id = z,
                        type = type,
                        body = x,
                        cat_message = y,
                        cloud_mode = cloud_mode,
                        shiny_progress_code = shiny_progress_code
      )
    }
  ))
}



#' .guess_col_type
#'
#' Write pulled data to temp folder and read back in with read_csv and utilise
#' col_guess()
#'
#' @param data
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return data
.guess_col_type <- function(data) {
  data %>%
    readr::type_convert(col_types = readr::cols()) %>%
    dplyr::mutate_if(lubridate::is.difftime, ~
                       format(strptime(., format = '%H:%M:%S'), '%I:%M %p'))
}


#' .create_date_from_last_x
#'
#' Finds start date from 'last' argument in pull_smartabase()
#'
#' @param last
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return start_date
.create_date_from_last_x <- function(last) {
  last <- tolower(last)

  if (!last == "today") {
    word_count <- sapply(strsplit(last, " "), length)

    if (word_count != 2) {
      stop(paste("'last' argument must either read 'today' or must contain a",
                 "number and a date unit; e.g. 1, 7, 14 etc. and a date unit",
                 "e.g. days, weeks, months or years)"), call. = FALSE)
    }

    number <- suppressWarnings(as.numeric(stringr::word(last, 1)))

    if (is.na(number)) {
      stop(paste("number in 'last' argument must be a numeric; e.g. '7 days'",
                 "not 'seven days'"), call. = FALSE)
    }

    start_date <- tryCatch({
      if (stringr::word(last, 2) == "months") {
        format(
          lubridate::today() -
            eval(parse(text = paste(stringr::word(last, 2))))(number),
          "%d/%m/%Y"
        )

      } else {
        format(
          lubridate::today() -
            eval(parse(text = paste("lubridate::", stringr::word(last, 2))))(number),
          "%d/%m/%Y"
        )
      }
    }, error = function(e) {
      stop("date unit in 'last' argument must be either 'days', 'weeks',",
           "'months' or 'years'", call. = FALSE)
    })

  } else {
    start_date <- format(lubridate::today(), "%d/%m/%Y")
  }
  start_date
}
