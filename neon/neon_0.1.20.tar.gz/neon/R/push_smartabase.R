#' push_smartabase
#'
#' Uploads a dataframe to a Smartabase event or profile form
#'
#' The push_smartabase() function uses the Smartabase API and imports and R
#' dataframe into a specific Smartabase event or profile form. Set
#' 'type' = "profile" to push to a profile form. For more details see the
#' help vignette:
#' \code{vignette("getting-started", package = "neon")}
#'
#' @param df dataframe: data to be uploaded to Smartabase
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param form string: Name of Smartabase form
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param entered_by_user_id string: user ID of user uploading the data --
#' ignore if setup with save_credentials()
#' @param type string: either 'event' or 'profile'
#' @param get_id boolean: if TRUE, searches for user IDs of athletes listed
#' in dataframe (requires a value supplied to 'match_id_to_column')
#' @param match_id_to_column string: names of columns in dataframe that match
#' either 'about', 'username' or 'email'. User IDs will be returned that match
#' dataframe values. Requires 'get_id' = TRUE
#' @param table_fields vector: supply a vector of column names that are going
#' to be uploaded into a table. In Smartabase, this is equivalent to ticking
#' 'Treat all records for the same user, on the same day as a single record?'
#' @param start_date string: name of start date column in dataframe. If NULL,
#' and 'Date' or 'start_date' are not already columns in the dataframe, creates
#' a new start_date column based on current date
#' @param end_date string: name of end date column in dataframe. If NULL, and
#' 'end_date' is not already a column in the dataframe, creates a new
#' 'end_date' column based on 'start_date'
#' @param start_time string: name of start time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'start_time' is not already a
#' column in the dataframe, creates a new 'start_time' column based on
#' Sys.time()
#' @param end_time string: name of end time column in dataframe with
#' 'h:mm AM' or 'h:mm PM' records. If NULL, and 'end_time' is not already a
#' column in the dataframe, creates a new 'end_time' column with values +1 hour
#' after 'start_time'
#' @param current_date_format string: current format of date variable of
#' interest. Set this argument to convert 'start_date' or 'end_date' to
#' dd/mm/yyyy
#' @param edit_event boolean: if TRUE, will look for 'event_id' in dataframe.
#' Records with matching event_id on Smartabase will be overwritten with the
#' new data
#' @param cloud_mode boolean: if TRUE, confirmation pop-up will not appear when
#' editing events (i.e. for use in non-local, cloud environments)
#' @param shiny_progress_code string: shinyhttr code to pass progress bar to
#' a shiny app
#'
#' @return http response

#' @importFrom magrittr %>%
#'
#' @examples
#' \dontrun{
#' example_df <- dplyr::tibble(
#'   user_id = c(31813, 31819),
#'   `Body Weight pre training` = round(runif(2, 82, 92), 0),
#'   `Body Weight post training` = round(runif(2, 82, 92), 0),
#'   `Urine Colour` = round(runif(2, 1, 8), 0)
#' )
#' push_smartabase(
#'   df = example_df,
#'   url = "example.smartabase.com/site",
#'   username = "john.smith",
#'   form = "Hydration",
#'   entered_by_user_id = 31822
#' )
#' }
#'
#' @export
push_smartabase <- function(
  df,
  form,
  url = NULL,
  username = NULL,
  password = NULL,
  entered_by_user_id = NULL,
  type = "event",
  get_id = FALSE,
  match_id_to_column = NULL,
  table_fields = NULL,
  start_date = NULL,
  end_date   = NULL,
  current_date_format = NULL,
  start_time = NULL,
  end_time   = NULL,
  edit_event = FALSE,
  cloud_mode = FALSE,
  shiny_progress_code = NULL
) {

  if (exists("table_fields") && identical(table_fields, "")) {
    table_fields <- NULL
  }

  username <- .get_username(username)

  password <- .get_password(password)

  url <- stringr::str_replace(.get_url(url), "https://", "")

  if (password == "prompt") {
    password <- getPass::getPass(msg = paste("Smartabase password for", username, "at", url))
  }

  df <- .prepare_data(
      df = df,
      url = url,
      form = form,
      type = type,
      username = username,
      password = password,
      entered_by_user_id = entered_by_user_id,
      match_id_to_column = match_id_to_column,
      get_id = get_id,
      table_fields = table_fields,
      start_date = start_date,
      end_date   = end_date,
      current_date_format = current_date_format,
      start_time = start_time,
      end_time   = end_time,
      edit_event = edit_event,
      cloud_mode = cloud_mode
    )

  duplicate_test <- df %>%
    dplyr::group_by(.data$start_date, .data$user_id) %>%
    dplyr::summarise(duplicate_date = dplyr::n()) %>%
    dplyr::ungroup() %>%
    dplyr::summarise(max_row = max(.data$duplicate_date)) %>%
    dplyr::pull(.data$max_row)

  .push_confirmation_message(
    df = df, duplicate_test = duplicate_test, url = url, form = form,
    type = type, username = username, password = password,
    entered_by_user_id = entered_by_user_id, get_id = get_id,
    match_id_to_column = match_id_to_column, table_fields = table_fields,
    start_date = start_date, end_date = end_date, start_time = start_time,
    end_time = end_time, edit_event = edit_event, cloud_mode = cloud_mode
  )

  if (is.null(entered_by_user_id)) {
    if (.rm_delim("entered_by_user_id") %in% .rm_delim(tolower(names(df)))) {
      unique_entered_by_user_id <- unique(df$entered_by_user_id)

      if (length(unique_entered_by_user_id) > 1) {
        warning(
          paste(
            "multiple entered_by_user_id values were detected.",
            "The API will be invoked separately for each entered_by_user_id.\n"
          ),
          call. = FALSE, immediate. = TRUE
        )
      }
    }
  }

  if (duplicate_test > 1 & is.null(table_fields)) {
    if (!cloud_mode) {
      warning(
        paste(
          "multiple records with the same user_id/start_date were detected.",
          "Given that table_fields = NULL, the API will be invoked multiple times.\n"
        ),
        call. = FALSE, immediate. = TRUE
      )
    }

    df <- df %>%
      dplyr::group_by(.data$start_date, .data$user_id) %>%
      dplyr::mutate(row_num = 1:dplyr::n()) %>%
      dplyr::ungroup() %>%
      split(.$row_num)

    invisible(
      df %>%
        purrr::map(~ .prepare_data_and_push(
          df = .x, url = url, form = form, type = type, username = username,
          password = password, entered_by_user_id = entered_by_user_id,
          get_id = get_id, match_id_to_column = match_id_to_column,
          table_fields = table_fields, start_date = start_date,
          end_date = end_date, start_time = start_time, end_time = end_time,
          edit_event = edit_event, cloud_mode = cloud_mode,
          shiny_progress_code = shiny_progress_code
          ))
    )
  } else {
    invisible(
      .prepare_data_and_push(
        df = df, url = url, form = form, type = type, username = username,
        password = password, entered_by_user_id = entered_by_user_id,
        get_id = get_id, match_id_to_column = match_id_to_column,
        table_fields = table_fields, start_date = start_date,
        end_date = end_date, start_time = start_time, end_time = end_time,
        edit_event = edit_event, cloud_mode = cloud_mode,
        shiny_progress_code = shiny_progress_code
      )
    )
  }

}
