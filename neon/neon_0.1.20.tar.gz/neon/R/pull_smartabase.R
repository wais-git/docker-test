#' pull_smartabase
#'
#' Downloads data from a Smartabase event or profile form
#'
#' This function pulls data from a Smartabase event form or profile form using
#' the Smartabase API. For more details see the help vignette:
#' \code{vignette("pulling-data", package = "neon")}
#'
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param form string: name of Smartabase form
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param type string: either 'event', 'profile' or 'synchronise'
#' @param download_attachment boolean: if TRUE, will download any files that
#' are included in the form via a file upload/multiple file upload field
#' @param start_date string: 'dd/mm/yyyy'
#' @param end_date string: 'dd/mm/yyyy'
#' @param last string: string indicating how many of the last days, weeks,
#' months or years data should be pulled for; e.g. '7 days'. Can supply
#' 'today' to pull only today's data. Only works if start_date and end_date
#' are NULL.
#' @param start_time string: 'h:mm AM' or 'h:mm PM'
#' @param end_time string: 'h:mm AM' or 'h:mm PM'
#' @param filter_user_key string: 'about', 'username', 'email', 'group' or
#' 'current_group'
#' @param filter_user_value strings: values indicated by
#' 'filter_user_key'. E.g. if filter_user_key = 'about', expects full names of
#' athletes to filter for
#' @param filter_data_key strings: names of Smartabase fields. Multiple can be
#' supplied in a vector
#' @param filter_data_value strings: values indicated by filter_data_key,
#' e.g. if form has a field called 'RPE' and filter_data_key = 'RPE', then
#' valid RPE values must be supplied. Multiple filter_data_value can be
#' supplied in a vector the same length as filter_data_key
#' @param filter_data_condition strings: '=' or 'equal_to'; '!=' or
#' 'not_equal_to'; '%in%' or 'contains'; '<' or 'less_than'; '>' or
#' 'greater_than'; '<=' or 'less_than_or_equal_to'; '>=' or
#' 'greater_than_or_equal_to'. Multiple filter_data_condition can be
#' supplied in a vector the same length as filter_data_key
#' @param include_missing_users boolean: if TRUE, includes users who have not
#' recorded data in that form as rows of NA values
#' @param guess_col_type boolean: if TRUE, pull_smartabase() guesses the the
#' data type of each column and appends the guess to tibble's heading
#' @param get_uuid boolean: if TRUE, return Smartabase uuid
#' @param cloud_mode boolean: if TRUE, no progress bar appears (i.e. for use
#' in non-local, cloud environments)
#' @param last_sync_time numeric: last time pull_smartabase() was synched with
#' server, in epoch time
#' @param shiny_progress_code string: shinyhttr code to pass progress bar to
#' a shiny app
#'
#' @return Smartabase data
#'
#' @examples
#' \dontrun{
#' # Get one week of wellness data from example.smartabase.com/site:
#' wellness_data <- pull_smartabase(
#'   url = "example.smartabase.com/site",
#'   form = "Daily Wellness",
#'   username = "john.smith",
#'   password = "examplePassword",
#'   start_date = "15/04/2019",
#'   end_date = "22/04/2019"
#' )
#' }
#'
#' @export
pull_smartabase <- function(
  form,
  url = NULL,
  type = "event",
  download_attachment = FALSE,
  start_date = NULL,
  end_date = NULL,
  last = NULL,
  start_time = "00:00 AM",
  end_time = "11:59 PM",
  username = NULL,
  password = NULL,
  filter_user_key = NULL,
  filter_user_value = NULL,
  filter_data_key = NULL,
  filter_data_value = NULL,
  filter_data_condition = "equal_to",
  include_missing_users = FALSE,
  guess_col_type = TRUE,
  get_uuid = FALSE,
  cloud_mode = FALSE,
  last_sync_time = NULL,
  shiny_progress_code = NULL
) {

  if (exists("filter_user_key") && identical(filter_user_key, "")) {
    filter_user_key <- NULL
  }

  if (exists("filter_user_value") && identical(filter_user_value, "")) {
    filter_user_value <- NULL
  }

  if (exists("filter_data_key") && identical(filter_data_key, "")) {
    filter_data_key <- NULL
  }

  if (exists("filter_data_condition") && identical(filter_data_condition, "")) {
    filter_data_condition <- "equal_to"
  }

  if (exists("filter_data_value") && identical(filter_data_value, "")) {
    filter_data_value <- NULL
  }

  if (!is.null(last)) {
    if (!is.null(start_date) | !is.null(end_date)) {
      warning("last will be ignored since either start_date and/or end_date are
              not NULL", call. = FALSE, immediate. = TRUE)
    }

    start_date <- .create_date_from_last_x(last)
    end_date <- format(lubridate::today(), "%d/%m/%Y")
  }

  if (!is.null(start_date)) {
    .check_date(date = start_date)
  }

  if (!is.null(end_date)) {
    .check_date(date = end_date)
  }

  if (!is.null(start_time)) {
    .check_time(time = start_time)
  }

  if (!is.null(end_time)) {
    .check_time(time = end_time)
  }

  username <- .get_username(username)

  password <- .get_password(password)

  url <- stringr::str_replace(.get_url(url), "https://", "")

  if (password == "prompt") {
    password <- getPass::getPass(msg = paste("Smartabase password for", username, "at", url))
  }

  form_no_space <- gsub(" ", "+", utils::URLencode(form, reserved = TRUE), fixed = TRUE)

  allowed_user_vars <- c("about", "user_id", "username", "email", "group", "current_group")

  if (!is.null(filter_user_key)) {
    if (!filter_user_key %in% allowed_user_vars) {
      stop(paste("filter_user_key must be either 'about', 'user_id'",
                 "'username', 'email', 'group' or 'current_group'"),
           call. = FALSE)
    }
  }

  id_data <- get_id(url = url,
                    filter_user_key = filter_user_key,
                    filter_user_value = filter_user_value,
                    start_date = "01/01/1970",
                    end_date = .date_convert(lubridate::today()),
                    username = username,
                    password = password,
                    get_uuid = get_uuid) %>%
    dplyr::select(-c(.data$username, .data$email)) %>%
    dplyr::distinct()

  user_id <- id_data %>% dplyr::pull(.data$user_id)

  if (type == "profile") {
    smartabase_url <- .create_url(url, "pull_profile")
    body <- jsonlite::toJSON(list(
      formNames  = form,
      userIds    = user_id
    ), auto_unbox = TRUE)

  } else if (type == "synchronise") {
    smartabase_url <- .create_url(url, "synchronise")

    if (is.null(last_sync_time)) {
      body <- jsonlite::toJSON(list(
        formName = form,
        userIds = user_id
      ), auto_unbox = TRUE)

    } else {
      body <- jsonlite::toJSON(list(
        formName = form,
        userIds = user_id,
        lastSynchronisationTimeOnServer = last_sync_time
      ), auto_unbox = TRUE)
    }

  } else {
    if (any(is.null(start_date), is.null(end_date))) {
      stop(paste("Both start_date and end_date must be",
                 "supplied when type = event"), call. = FALSE)
    }

    if (is.null(filter_data_key)) {
      smartabase_url <- .create_url(url, "pull_event")
      body <- jsonlite::toJSON(list(
        formNames  = form,
        userIds    = user_id,
        startDate  = start_date,
        finishDate = end_date,
        startTime  = start_time,
        finishTime = end_time
      ), auto_unbox = TRUE)

    } else {
      length_key <- length(filter_data_key)
      length_condition <- length(filter_data_condition)
      length_value <- length(filter_data_value)

      all_equal_length <- all(
        purrr::map_lgl(
          list(length_condition, length_value), function(x) x == length_key
        )
      )

      if (any(duplicated(filter_data_key))) {
        stop("filter_data_key cannot have duplicate elements", call. = FALSE)
      }

      if (!all_equal_length) {
        if (length_key == 1) {
          if (length_condition > 1 | length_value > 1) {
            stop(paste("filter_data_key, filter_data_condition and filter_data_value",
                       "must be the same length"), call. = FALSE)
          }
        } else {
          if (length_key == length_condition && length_value == 1) {
            filter_data_value <- rep(filter_data_value, length_key)

          } else if (length_key == length_value && length_condition == 1) {
            filter_data_condition <- rep(filter_data_condition, length_key)

          } else if (length_condition == 1 && length_value == 1) {
            filter_data_condition <- rep(filter_data_condition, length_key)
            filter_data_value <- rep(filter_data_value, length_key)
          } else {
            stop(paste("filter_data_key, filter_data_condition and filter_data_value",
                       "must be the same length"), call. = FALSE)
          }
        }
      }

      select_condition <- function(filter_data_condition) {
        if (filter_data_condition == "equal_to" | filter_data_condition == "=") {
          1
        } else if (filter_data_condition == "not_equal_to" | filter_data_condition == "!=") {
          2
        } else if (filter_data_condition == "contains" | filter_data_condition == "%in%") {
          3
        } else if (filter_data_condition == "less_than" | filter_data_condition == "<") {
          4
        } else if (filter_data_condition == "greater_than" | filter_data_condition == ">") {
          5
        } else if (filter_data_condition == "less_than_or_equal_to" | filter_data_condition == "<=") {
          6
        } else if (filter_data_condition == "greater_than_or_equal_to" | filter_data_condition == ">=") {
          7
        }
      }

      filter_data_condition <- 1:length(filter_data_condition) %>%
        purrr::map(~ select_condition(filter_data_condition[[.x]])) %>%
        purrr::reduce(., c)

      filter_list <- list(list(
        formName = form,
        filterSet = seq_along(filter_data_value) %>%
          purrr::map(~ list(key = filter_data_key[[.x]],
                            value = as.character(filter_data_value[[.x]]),
                            filterCondition = filter_data_condition[[.x]]))
      ))

      smartabase_url <- .create_url(url, "pull_filtered_event")
      body <- jsonlite::toJSON(list(
        formNames  = form,
        userIds    = user_id,
        startDate  = start_date,
        finishDate = end_date,
        startTime  = start_time,
        finishTime = end_time,
        filter     = filter_list
      ), auto_unbox = TRUE)
    }
  }

  if (!cloud_mode) {
    cat(paste(form, "data is downloading... ", "\n\n"))

    if (is.null(shiny_progress_code)) {
      post <- httr::POST(
        url = smartabase_url,
        httr::authenticate(username, password, type = "basic"),
        encode = "json",
        httr::content_type_json(),
        body = body,
        verbose = FALSE,
        httr::progress(type = "up")
      )
    } else {
      post <- httr::POST(
        url = smartabase_url,
        httr::authenticate(username, password, type = "basic"),
        encode = "json",
        httr::content_type_json(),
        body = body,
        verbose = FALSE,
        eval(shiny_progress_code)
      )
    }
  } else {
    post <- httr::POST(
      url = smartabase_url,
      httr::authenticate(username, password, type = "basic"),
      encode = "json",
      httr::content_type_json(),
      body = body,
      verbose = FALSE
    )
  }

  if (httr::http_error(post)) {
    data <- NULL
    stop(paste("Please check that your username, password, url",
               "and form are correct"), call. = FALSE)
  }

  auth_status <- httr::http_status(post)[["category"]]

  auth_message <- httr::http_status(post)[["message"]]

  auth_message <- paste("Authentication", tolower(auth_message))

  if (auth_status == "Success") {
    data <- tryCatch({
      jsonlite::fromJSON(httr::content(post, "text", encoding = "UTF-8"))
    }, error = function(e) {
      stop(paste0("No data was retrieved for ",
                  form,
                  "\n",
                  "Please check that the filter conditions are correct"),
           call. = FALSE)
    })

    if (rlang::is_empty(data)) {
      message("\n", auth_message)
      stop(paste0("No data was retrieved for ",
                  form,
                  "\n",
                  "Please check that the filter conditions are correct"),
           call. = FALSE)
    }

    if (type != "synchronise") {
      type_filter <- paste0(type, "s")
      data <- data[type_filter][[1]]

    } else {
      last_sync_time <- data[["lastSynchronisationTimeOnServer"]]
      deleted_events <- data[["idsOfDeletedEvents"]]
      data <- data[["export"]][["events"]]
    }

    if (!"rows" %in% names(data)) {
      data <- NULL

    } else {
      data <- data %>%
        dplyr::filter(.data$rows != "NULL")

      if (nrow(data) == 0) {
        data <- NULL
      }
    }

    if (!is.null(data)) {
      metadata <- data %>%
        dplyr::select(.data$formName:.data$enteredByUserId, .data$id)

      if (download_attachment) {
        attachment_data <- data %>%
          dplyr::full_join(., id_data %>% dplyr::rename(userId = user_id), by = "userId") %>%
          tidyr::unnest(c(.data$attachmentUrl, .data$rows)) %>%
          dplyr::rename(attachment_url = .data$attachmentUrl) %>%
          dplyr::filter(!is.na(.data$attachment_url)) %>%
          dplyr::select(-c(.data$row, .data$pairs)) %>%
          tidyr::unite(
            col = "file_name",
            .data$formName, .data$about, .data$startDate, .data$startTime, .data$name,
            remove = FALSE
          ) %>%
          dplyr::select(-.data$about) %>%
          dplyr::mutate_at("file_name", ~ stringr::str_remove_all(., "/")) %>%
          dplyr::mutate_at("file_name", ~ stringr::str_remove_all(., ":| "))

        if (!cloud_mode) {
          cat(paste0("\nDownloading ", nrow(attachment_data), " attachments from ", form, "...\n"))
        }

        handle <- httr::handle_find(smartabase_url)

        if (exists("cookie")) {
          rm(cookie)
        }

        cookie <- post$cookies$value

        attachment_reponse <-
          tryCatch({
            attachment_data %>%
              dplyr::mutate(row_num = dplyr::row_number()) %>%
              split(.$row_num) %>%
              purrr::map(
                ~ httr::GET(
                  .x[["attachment_url"]],
                  httr::authenticate(username, password, type = "basic"),
                  httr::set_cookies(cookie),
                  httr::content_type_json(),
                  verbose = FALSE,
                  httr::write_disk(.x[["file_name"]], overwrite = TRUE),
                  httr::progress(type = "up"),
                  handle = handle
                )
              )
          }, error = function(e) {
            e
          })

        httr::handle_reset(handle$url)

        attachment_error <- any(class(attachment_reponse) == "error")

        if (attachment_error) {
          attachment_path_exists <- stringr::str_detect(
            attachment_reponse$message, "Path exists and overwrite is FALSE"
          )

          if (attachment_path_exists) {
            attachment_message <- paste(form, "attachment download failed: files already exist in", getwd())
          } else {
            attachment_message <- paste(form, "attachment download failed": attachment_reponse$message)
          }
        } else {
          attachment_message <- attachment_reponse %>%
            purrr::map_df(~ tibble::tibble(
              status = httr::http_status(.x)[[1]],
              size = as.numeric(.x$headers$`content-length`)/1000000
            )) %>%
            dplyr::mutate_at("status", ~ dplyr::if_else(. == "Success", 1, 0)) %>%
            dplyr::summarise(success_sum = sum(.data$status), n_rows = dplyr::n(), size_sum = sum(.data$size))

          attachment_size <- attachment_message$size_sum

          if (attachment_size < 1) {
            attachment_size <- attachment_size * 1000
            attachment_unit <- "kb"
          } else {
            attachment_unit <- "mb"
          }

          attachment_message <- paste0(
            form, " attachment download successful: ",
            attachment_message$success_sum,
            " out of ",
            attachment_message$n_rows,
            " files (",
            round(attachment_size, 2),
            attachment_unit,
            " total) saved to ",
            getwd()
          )
        }
      }

      if (download_attachment) {
        rows <- data %>%
          dplyr::select(.data$rows, .data$attachmentUrl) %>% .[[1]]
      } else {
        rows <- data %>%
          dplyr::select(.data$rows) %>% .[[1]]
      }

      pairs_data <- 1:length(rows) %>%
        purrr::map(~ rows[[.x]]["pairs"])

      data <-
        purrr::map_df(1:length(pairs_data), function(x) {
          purrr::map_df(1:nrow(pairs_data[[x]]), function(y) {
            tidyr::pivot_wider(
              pairs_data[[x]][[1]][[y]] %>% dplyr::distinct(.data$key, .keep_all = TRUE),
              names_from = .data$key, values_from = .data$value
            ) %>%
              dplyr::bind_cols(metadata[x, ], .) %>%
              dplyr::as_tibble()
          })
        })

      if (guess_col_type) {
        data <- .guess_col_type(data)

        if (download_attachment && !attachment_error) {
          attachment_data <- .guess_col_type(attachment_data)
        }
      }

      if (type == "profile") {
        data <- data %>%
          dplyr::rename(
            form               = .data$formName,
            user_id            = .data$userId,
            entered_by_user_id = .data$enteredByUserId,
            event_id           = .data$id
          )

      } else {
        rename_metadata <- function(dat) {
          dat %>%
            dplyr::rename(
              form               = .data$formName,
              start_date         = .data$startDate,
              start_time         = .data$startTime,
              end_date           = .data$finishDate,
              end_time           = .data$finishTime,
              user_id            = .data$userId,
              entered_by_user_id = .data$enteredByUserId,
              event_id           = .data$id
            )
        }
        data <- rename_metadata(data)

        if (download_attachment && !attachment_error) {
          attachment_data <- rename_metadata(attachment_data)

          data <- dplyr::full_join(data, attachment_data, by = get_metadata_names(data))
        }
      }

      date_col <- data %>%
        dplyr::select(
          names(data)[stringr::str_detect(names(data), stringr::fixed("date", ignore_case = TRUE)) &
                        !stringr::str_detect(names(data), "start_date|end_date")]
        ) %>%
        dplyr::select_if(is.numeric) %>%
        names(.)

      if (stringr::str_detect(Sys.timezone(), "America") | stringr::str_detect(Sys.timezone(), "US/")) {
        date_format <- "%m/%d/%Y"

      } else {
        date_format <- "%d/%m/%Y"
      }

      data <- data %>%
        dplyr::mutate_at(
          date_col, ~
            format(as.Date(stringr::word(lubridate::as_datetime(./1000, tz = Sys.timezone()), 1)), date_format)
        )

      if (type != "profile") {
        first_metadata_cols <- c("about", "user_id", "form", "start_date")
        last_metadata_cols  <- c("start_time", "end_date", "end_time",
                                 "entered_by_user_id", "event_id", "file_name", "attachment_url", "name")
      } else {
        first_metadata_cols <- c("about", "user_id", "form")
        last_metadata_cols  <- c("entered_by_user_id", "event_id")
      }

      if (get_uuid) {
        last_metadata_cols <- c(last_metadata_cols, "uuid")
      }

      pulled_cols <- data %>%
        dplyr::select(-tidyselect::any_of(c(first_metadata_cols, last_metadata_cols))) %>%
        colnames(.)

      if (include_missing_users) {
        data <- data %>%
          dplyr::full_join(., id_data, by = "user_id") %>%
          dplyr::select(tidyselect::any_of(c(first_metadata_cols, pulled_cols, last_metadata_cols)))

      } else {
        data <- data %>%
          dplyr::left_join(., id_data, by = "user_id") %>%
          dplyr::select(tidyselect::any_of(c(first_metadata_cols, pulled_cols, last_metadata_cols)))
      }

      data_message <- paste0(form, " download successful: ", nrow(data), " rows retrieved")

      if (download_attachment) {
        full_message <- paste0("\n", auth_message, "\n", data_message, "\n", attachment_message, "\n")
      } else {
        full_message <- paste0("\n", auth_message, "\n", data_message, "\n")
      }

      message(full_message)
    }

    rm(password)

    if (type == "synchronise") {
      if (is.null(data)) {
        message(paste0("No new ", form, " data since last synchronisation"))
      }
      return(list(new_data = data, last_sync_time = last_sync_time, deleted_events = deleted_events))

    } else {
      if (is.null(data)) {
        stop(paste0("No data was retrieved for ",
                    form,
                    "\n",
                    "Please check that the filter conditions are correct"),
             call. = FALSE)
      } else {
        return(data)
      }
    }
  }
}
