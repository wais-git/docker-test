#' save_credentials
#'
#'Allows you to permanently store your Smartabase password,
#' username and user ID on your local machine.
#'
#' Calling this function will open a .Renviron file. This is a plain text
#' hidden file stored on your local machine. Add any of the four variables
#' in the format
#'
#' SB_USER = "john.smith" \cr
#' SB_PASS = "examplePassword" \cr
#' SB_ID   = 12345 \cr
#' SB_URL  = "example.smartabase.com/site"
#'
#' ...then save the file and restart R. You now don't need to supply the password,
#' username or entered_by_user_id arguments in 'pull_smartabase()' or
#' 'push_smartabase()'. For more details see the help vignette:
#' \code{vignette("getting-started", package = "neon")}
#'
#' @return Opens .Renviron file
#'
#' @examples
#' \dontrun{
#' save_credentials()
#' }
#'
#' @export
save_credentials <- function(){
  # writes message similar to brows_github_path()
  message("('.Renviron') file opened.\n")
  message("Store your Smartabase credentials in four lines like\n")
  message("SB_USER = 'john.smith'\n")
  message("SB_PASS = 'examplePassword'\n")
  message("SB_ID = 12345\n")
  message("SB_URL = 'example.smartabase.com/site'\n")
  message("Note: make sure ('.Renviron') ends with a newline!\n")
  usethis::edit_r_environ()
}


#' .get_username
#'
#' Checks for username in .Renviron file or function call
#'
#' This function checks if a username was supplied. If not, it will look in
#' .Renviron file.
#'
#' @param username string: if not saved with 'save_credentials()', expects
#' Smartabase login username
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return A list of credentials
.get_username <- function(username = NULL) {

  if (is.null(username)) {
    username <- Sys.getenv("SB_USER")
    if (identical(username, "")) {
      stop("'username' not supplied nor set via 'save_credentials()'", call. = FALSE)
    }
  } else {
    username <- username
  }

  return(username)
}


#' .get_password
#'
#' Checks for password in .Renviron file or function call
#'
#' This function checks whether password was supplied. If not, will look in
#' .Renviron file. If password = 'prompt', a pop-up will appear.
#'
#' @param password string: if not saved with 'save_credentials()', will default
#' to asking user by opening a masked password input, otherwise expects
#' password as a string
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return A list of credentials
.get_password <- function(password = NULL) {

  if (is.null(password)) {
    password <- Sys.getenv("SB_PASS")
    if (identical(password, "")) {
      password <- "prompt"
    }
  } else {
    password <- password
  }

  return(password)
}


#' .get_entered_by_user_id
#'
#' Checks for entered_by_user_id in .Renviron file or function call
#'
#' This function checks whether entered_by_user_id was supplied. If not, will
#' look in .Renviron file.
#'
#' @param entered_by_user_id string: if not saved with 'save_credentials()',
#' expects Smartabase user ID of person uploading the data
#' @param verbose boolean: if TRUE, warning message will be displayed
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return string: entered_by_user_id saved in .Renviron
.get_entered_by_user_id <- function(entered_by_user_id = NULL) {

  if (is.null(entered_by_user_id)) {
    entered_by_user_id <- Sys.getenv("SB_ID")

  } else {
    entered_by_user_id <- entered_by_user_id
  }

  entered_by_user_id <- as.numeric(entered_by_user_id)

  if (identical(entered_by_user_id, "") | is.na(entered_by_user_id)) {
      stop(paste("'entered_by_user_ID' not supplied nor set via 'save_credentials()'."), call. = FALSE)
  }

  return(entered_by_user_id)
}


#' .get_url
#'
#' Checks for url in .Renviron file or function call
#'
#' This function checks if a url was supplied. If not, it will look in
#' .Renviron file.
#'
#' @param username string: if not saved with 'save_credentials()', expects
#' Smartabase url
#'
#' @noRd
#'
#' @keywords internal
#'
#' @return string: url saved in .Renviron
.get_url <- function(url = NULL) {

  if (is.null(url)) {
    url <- Sys.getenv("SB_URL")
    if (identical(url, "")) {
      stop("'url' not supplied nor set via 'save_credentials()'", call. = FALSE)
    }
  } else {
    url <- url
  }

  return(url)
}
