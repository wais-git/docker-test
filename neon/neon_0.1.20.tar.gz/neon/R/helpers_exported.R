#' get_group
#'
#' Returns a dataframe of the groups accessible by your Smartabase
#' account. For more details see the help vignette:
#' \code{vignette("getting-started", package = "neon")}
#'
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site' --
#' ignore if setup with save_credentials()
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param id_message boolean: if TRUE, displays messages to screen about
#' retrieving user ID information. Only relevant when get_id = TRUE
#'
#' @return dataframe of available groups
#'
#' @examples
#' \dontrun{
#' # Assuming credentials have been setup with save_credentials(), otherwise
#' # must supply username, password and url:
#' get_group()
#' }
#'
#' @export
get_group <- function(url = NULL,
                      username = NULL,
                      password = NULL,
                      id_message = FALSE) {

  username <- .get_username(username)

  password <- .get_password(password)

  url <- stringr::str_replace(.get_url(url), "https://", "")

  if (password == "prompt") {
    password <- getPass::getPass(msg = paste("Smartabase password for", username, "at", url))

  } else {
    password <- password
  }

  body <- jsonlite::toJSON(list(name = ""), auto_unbox = TRUE)

  smartabase_url <- .create_url(url, "pull_group_names")

  if (id_message) {
    data_get <- httr::POST(
      url = smartabase_url,
      httr::authenticate(username, password, type = "basic"),
      encode = "json",
      httr::content_type_json(),
      body = body,
      verbose = FALSE,
      httr::progress(type = "up")
    )

  } else {

    data_get <- httr::POST(
      url = smartabase_url,
      httr::authenticate(username, password, type = "basic"),
      encode = "json",
      httr::content_type_json(),
      body = body,
      verbose = FALSE
    )
  }

  auth_status <- httr::http_status(data_get)[["category"]]

  auth_message <- httr::http_status(data_get)[["message"]]

  full_message <- paste0("Authentication ", tolower(auth_message))

  if (auth_status == "Success") {
    data <- tibble::tibble(Group = jsonlite::fromJSON(httr::content(data_get, "text", encoding = "UTF-8"))[[1]])

  } else {
    stop(paste(full_message), call. = FALSE)
  }

  if (id_message) {
    message(full_message)
  }

  return(data)
}


#' get_id
#'
#' get_id returns a dataframe of the user IDs accessible by your Smartabase
#' account. For more details see the help vignette:
#' \code{vignette("getting-started", package = "neon")}
#'
#' @param url string: Smartabase url e.g. 'example.smartabase.com/site'
#' @param username string: Smartabase username -- ignore if setup with
#' save_credentials()
#' @param password string: Smartabase password -- ignore if setup with
#' save_credentials()
#' @param start_date string: 'dd/mm/yyyy'
#' @param end_date string: 'dd/mm/yyyy'
#' @param filter_user_key string: 'about', 'username', 'email', 'group' or
#' 'current_group'
#' @param filter_user_value vector: values indicated by 'filter_user_key'. Data is
#' filtered by these values. If 'filter_user_key' = 'group', expects name(s) of
#' Smartabase group(s)
#' @param get_uuid boolean: if TRUE, return Smartabase uuid
#' @param id_message boolean: if TRUE, displays messages to screen about
#' retrieving user ID information. Only relevant when get_id = TRUE.
#'
#' @return JSON
#'
#' @examples
#' \dontrun{
#' example_df <- dplyr::data_frame(
#'   about = c("Jamie Anderson", "Charlie Thompson"),
#'   `Body Weight pre training` = round(runif(2, 82, 92), 0),
#'   `Body Weight post training` = round(runif(2, 82, 92), 0),
#'   `Urine Colour` = round(runif(2, 1, 8), 0)
#' )
#' user_id <- get_id(
#'   unique_about = unique(example_df$About),
#'   url = "demo.smartabase.com/apidev",
#'   username = "john.smith"
#' )
#' }
#'
#' @export
get_id <- function(url = NULL,
                   start_date = "01/01/1970",
                   end_date = .date_convert(lubridate::today()),
                   username = NULL,
                   password = NULL,
                   filter_user_key = NULL,
                   filter_user_value = NULL,
                   get_uuid = FALSE,
                   id_message = FALSE) {

  username <- .get_username(username)

  password <- .get_password(password)

  url <- stringr::str_replace(.get_url(url), "https://", "")

  if (password == "prompt") {
    password <- getPass::getPass(msg = paste("Smartabase password for", username, "at", url))

  } else {
    password <- password
  }

  if (is.null(filter_user_key)) {
    if (!is.null(filter_user_value)) {
      warning("'filter_user_value' will have no effect when 'filter_user_key' is NULL",
              call. = FALSE, immediate. = TRUE)
    }

    body <- jsonlite::toJSON(list(identification = NULL), auto_unbox = TRUE)

    smartabase_url <- .create_url(url, "pull_user")

  } else {

    if (filter_user_key == "current_group") {
      body <- jsonlite::toJSON(list(name = ""), auto_unbox = TRUE)

      smartabase_url <- .create_url(url, "pull_current")

    } else if (filter_user_key == "group") {
      body <- jsonlite::toJSON(list(name = filter_user_value), auto_unbox = TRUE)

      smartabase_url <- .create_url(url, "pull_group")

    } else {

      if (tolower(.rm_delim(filter_user_key)) == "about") {
        identification <- filter_user_value %>%
          purrr::map(~ list(firstName = stringr::word(.x, 1),
                            lastName  = stringr::word(.x, 2, -1)))

      } else if (filter_user_key == "user_id") {
        identification <- filter_user_value %>%
          purrr::map(~ list(userId = as.numeric(.x)))

      } else if (tolower(.rm_delim(filter_user_key)) == "username") {
        identification <- filter_user_value %>%
          purrr::map(~ list(username = .x))

      } else if (tolower(.rm_delim(filter_user_key)) == "email") {
        identification <- filter_user_value %>%
          purrr::map(~ list(emailAddress = .x))
      }

      body <- jsonlite::toJSON(list(identification = identification), auto_unbox = TRUE)
      smartabase_url <- .create_url(url, "pull_user")
    }
  }

  if (id_message) {
    data_get <- httr::POST(
      url = smartabase_url,
      httr::authenticate(username, password, type = "basic"),
      encode = "json",
      httr::content_type_json(),
      body = body,
      verbose = FALSE,
      httr::progress(type = "up")
    )

  } else {

    data_get <- httr::POST(
      url = smartabase_url,
      httr::authenticate(username, password, type = "basic"),
      encode = "json",
      httr::content_type_json(),
      body = body,
      verbose = FALSE
    )
  }

  if (rlang::is_empty(data_get[["content"]])) {
    stop(paste0("Could not retrieve user IDs.",
                "\n",
                "Please ensure that the url is correct.",
                "If the problem persists, please contact Fusion Sport."),
         call. = FALSE)
  }

  auth_status <- httr::http_status(data_get)[["category"]]

  auth_message <- httr::http_status(data_get)[["message"]]

  full_message <- paste0("Authentication ", tolower(auth_message))

  if (auth_status == "Success") {
    post_content <- jsonlite::fromJSON(httr::content(data_get, "text", encoding = "UTF-8"))

    data <- tryCatch({
      post_content[[1]][[2]] %>%
        purrr::map_df(~ .x %>%
                        dplyr::select(-dplyr::contains("groupsAndRoles"))
        ) %>%
        tibble::as_tibble() %>%
        {if (get_uuid) {
          dplyr::select(., user_id = .data$userId, .data$firstName, .data$lastName,
                        .data$username, email = .data$emailAddress, uuid = .data$uuid)
        } else {
          dplyr::select(., user_id = .data$userId, .data$firstName, .data$lastName,
                        .data$username, email = .data$emailAddress)
        }} %>%
        tidyr::unite("about", .data$firstName, .data$lastName, sep = " ")

    }, error = function(e) {
      warning(paste("No user IDs returned for", filter_user_key, "=", filter_user_value),
              call. = FALSE, immediate. = TRUE)
      dplyr::tibble(user_id = NA, about = NA, username = NA, email = NA)
    })

  } else {

    stop(paste(full_message), call. = FALSE)
  }

  if (id_message) {
    message(full_message)
  }
  return(data)
}


#' get_metadata_names
#'
#' Returns vector of metadata variables present in data frame
#'
#' Once data has been pulled in from Smartabase, it is often desirable to
#' retain the metadata variables (e.g. about, start_time etc.) in the data
#' frame before pushing back to Smartabase. Rather than having to repeatedly
#' write out the vector of metadata variables you want to retain, this helper
#' function will retain any metadata variables present in a dataframe; for
#' instance, when used in the select() function
#'
#' @param df dataframe: data to be uploaded to Smartabase
#'
#' @return Vector of metadata variable names
#'
#' @examples
#' \dontrun{
#' example_df <- dplyr::tibble(
#'   about = c("Jamie Anderson", "Charlie Thompson"),
#'   start_date = c("14/02/2020", "14/02/2020"),
#'   form = "Hydration",
#'   `Body Weight pre training` = round(runif(2, 82, 92), 0),
#'   `Body Weight post training` = round(runif(2, 82, 92), 0),
#'   `Urine Colour` = round(runif(2, 1, 8), 0),
#'   end_date = c("14/02/2020", "14/02/2020")
#' )
#' example_df %>% select(get_metadata_names(.))
#' select(example_df, get_metadata_names(example_df))
#' }
#'
#' @export
get_metadata_names <- function(df) {
  vars <- c("about", "user_id", "form", "start_date", "end_date", "start_time",
            "end_time", "entered_by_user_id", "event_id", "uuid")

  vars[vars %in% names(df)]
}
