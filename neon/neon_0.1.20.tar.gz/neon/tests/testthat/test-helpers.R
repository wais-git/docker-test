context("test-helpers")

test_that("json conversion passed", {
  df <- dplyr::tibble(
    user_id = c(31813, 31819),
    `Body Weight pre training` = round(runif(2, 82, 92), 0),
    `Body Weight post training` = round(runif(2, 82, 92), 0),
    `Urine Colour` = round(runif(2, 1, 8), 0)
  )

  expect_is(.df_to_json(
    df = df,
    form = "Hydration (SS)",
    get_id = FALSE,
    entered_by_user_id = 31822
  ), "list")

  expect_is(.df_to_json(
    df = df,
    form = "Hydration (SS)",
    get_id = FALSE,
    entered_by_user_id = 31822
  )[[1]], "json")


  # expect_error(.df_to_json("a"))
})

test_that("date conversion passed", {
  expect_equal(.date_convert("2018-12-11"), "11/12/2018")
})

# example_df <- dplyr::tibble(
#   start_time = c("04:30 PM", "04:45 PM"),
#   end_time = c("04:35 PM", "04:50 PM"),
#   start_date = c("24/01/2019", "24/01/2019"),
#   end_date = c("24/01/2019", "24/01/2019"),
#   user_id = c(31813, 31819),
#   `Body Weight pre training` = runif(2, 82, 92) %>% round(., 0),
#   `Body Weight post training` = runif(2, 82, 92) %>% round(., 0),
#   `Urine Colour` = runif(2, 1, 8) %>% round(., 0)
# )
#
# test_that("date check fails", {
#   expect_error(.check_date("01-31-18", delimiter = TRUE))
#   expect_error(.check_date("31/01/18", delimiter = FALSE))
#   expect_error(.check_date(31 / 01 / 2018))
#   expect_error(.check_date("31/01/2018", delimiter = FALSE))
#   expect_error(.check_date("31012018", delimiter = TRUE))
#   expect_error(.check_date("01312018", delimiter = FALSE))
# })
#
# test_that("date check passes", {
#   expect_null(.check_date("31/01/2018", delimiter = TRUE))
#   expect_null(.check_date("31012018", delimiter = FALSE))
# })
#
# test_that("time check fails", {
#   expect_error(.check_time("12:30"))
#   expect_error(.check_time("05:30"))
#   expect_error(.check_time("1:30 AM"))
#   expect_error(.check_time("00:30 AM"))
#   expect_error(.check_time("12-30 PM"))
# })
#
# test_that("time check passes", {
#   expect_null(.check_time("01:00 AM"))
#   expect_null(.check_time("01:00 PM"))
# })
#
# test_that("time check passes", {
#   expect_null(.check_time("12:00 PM"))
# })
#
# test_that("entered_by check passed", {
#   expect_error(.check_entered_by("31083"))
#   expect_error(.check_entered_by(3108))
#   expect_error(.check_entered_by(310836))
# })
